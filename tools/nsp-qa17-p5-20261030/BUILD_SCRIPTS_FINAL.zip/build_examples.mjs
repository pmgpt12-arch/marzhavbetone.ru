import fs from 'node:fs/promises';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const root='/workspace/scratch/1c70cef937ec/qa17-p5',outputDir='/workspace/scratch/1c70cef937ec/outputs/qa17-p5';
const source=JSON.parse(await fs.readFile(root+'/internal/EXAMPLE_SOURCE.json','utf8'));const manifests=[];
for(const code of ['22','23','29']){
 const src=source[code],v=src.values,w=Workbook.create(),s=w.worksheets.add('Пример заполнения');
 const widths=code==='22'?[18,20,18,13,18,16,23,25]:code==='23'?[5,20,26,19,17,17,20,22,24]:[5,19,26,17,16,19,21,25];
 const last=String.fromCharCode(64+widths.length);s.showGridLines=false;s.getRange(`A1:${last}100`).format.font={name:'Arial',size:10};s.getRange(`A1:${last}100`).format.wrapText=true;s.getRange(`A1:${last}100`).format.verticalAlignment='top';
 widths.forEach((x,i)=>s.getRange(`${String.fromCharCode(65+i)}1:${String.fromCharCode(65+i)}100`).format.columnWidth=x);
 let row=1,breaks=[],sections=[],allContent=[];
 function merged(text,height=30,bold=false){s.mergeCells(`A${row}:${last}${row}`);s.getRange(`A${row}`).values=[[text]];s.getRange(`A${row}:${last}${row}`).format.rowHeight=height;s.getRange(`A${row}`).format.font={name:'Arial',size:bold?13:10,bold};allContent.push(text);row++;}
 merged('Пример заполнения',28,true);merged(v[1][0],38);row++;
 const groups=code==='22'?[[0,1,2,3,4,5,6,7],[0,1,8,9,10,11,12,13]]:code==='23'?[[0,1,2,3,4,5],[0,1,2,6,7,8,9,10,11]]:[[0,1,2,3,4,5,6,7],[0,1,2,8,9,10,11,12],[0,1,2,13,14,15,16,17],[0,1,2,18,19,20]];
 for(let g=0;g<groups.length;g++){
  if(g>0){breaks.push(row-1);row++;}
  const indices=groups[g],start=row;merged(`Лист «${code==='29'?'Опись':'Реестр'}». Часть ${g+1} из ${groups.length}`,25,true);
  const headers=indices.map(i=>v[4][i]??'');const end=String.fromCharCode(64+headers.length);
  s.getRange(`A${row}:${end}${row}`).values=[headers];s.getRange(`A${row}:${end}${row}`).format={fill:'#31363C',font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},wrapText:true,rowHeight:60,verticalAlignment:'center'};allContent.push(...headers);row++;
  const count=code==='29'?4:3;
  for(let j=0;j<count;j++){
   const vals=indices.map(i=>v[5+j][i]??'');const maxLines=Math.max(...vals.map((t,k)=>String(t).split('\n').reduce((n,x)=>n+Math.max(1,Math.ceil(x.length/(widths[k]*1.04))),0)));
   s.getRange(`A${row}:${end}${row}`).values=[vals];s.getRange(`A${row}:${end}${row}`).format.rowHeight=Math.max(46,maxLines*13+12);s.getRange(`A${row}:${end}${row}`).format.font={name:'Arial',size:10,color:'#184B7A'};s.getRange(`A${row}:${end}${row}`).format.borders={preset:'all',style:'thin',color:'#D0D0D0'};allContent.push(...vals.map(String));row++;
  }
  sections.push({group:g+1,startRow:start,endRow:row-1,sourceColumns:indices});row++;
 }
 breaks.push(row-1);row++;merged('Пояснения к примеру',27,true);
 const noteRows=code==='22'?[9]:code==='23'?[9,13]:[10,19];
 for(const r of noteRows){const text=v[r][0];if(text)merged(text,Math.max(42,Math.ceil(text.length/(widths.reduce((a,b)=>a+b,0)*1.04))*13+14));}
 merged('Лист «Сводка»',27,true);
 const summaryRows=code==='22'?[12,13,14]:code==='23'?[12]:[13,14,15,16,17];
 for(const r of summaryRows){
  const label=v[r][0]??'',val=v[r][1]??'';const mid=code==='23'?'C':'D',next=code==='23'?'D':'E';s.mergeCells(`A${row}:${mid}${row}`);s.mergeCells(`${next}${row}:${last}${row}`);s.getRange(`A${row}`).values=[[label]];s.getRange(`${next}${row}`).values=[[val]];s.getRange(`A${row}:${last}${row}`).format.rowHeight=Math.max(42,Math.ceil(String(val).length/(widths.slice(code==='23'?3:4).reduce((a,b)=>a+b,0)*1.04))*13+12);allContent.push(String(label),String(val));row++;
 }
 w.recalculate();const out=await SpreadsheetFile.exportXlsx(w);const name='example-'+code+'.xlsx';await out.save(outputDir+'/'+name);
 manifests.push({code,sourceFilename:src.filename,authoredFilename:name,lastColumn:last,lastRow:row-1,breaks,sections,content:allContent});console.log(code,'rows',row-1);
}
await fs.writeFile(root+'/internal/EXAMPLE_LAYOUT_MANIFEST.json',JSON.stringify(manifests,null,2));
