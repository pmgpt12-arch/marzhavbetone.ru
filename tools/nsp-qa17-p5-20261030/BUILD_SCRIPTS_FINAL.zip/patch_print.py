from pathlib import Path
import zipfile,json,copy,re,hashlib
from lxml import etree as E
R=Path(__file__).resolve().parent
N='http://schemas.openxmlformats.org/spreadsheetml/2006/main';q=lambda n:'{'+N+'}'+n
def xml(b):return E.fromstring(b)
def pack(e):return E.tostring(e,xml_declaration=True,encoding='UTF-8',standalone=True)
def node(e,n):
 t=e.find(q(n))
 if t is None:t=E.SubElement(e,q(n))
 return t
def coords(a):
 from openpyxl.utils.cell import range_boundaries,get_column_letter
 x1,y1,x2,y2=range_boundaries(a)
 return [get_column_letter(x)+str(y)for y in range(y1,y2+1)for x in range(x1,x2+1)]
report=[]
for plan in json.loads((R/'internal/XLSX_AUTHORED_PLAN.json').read_text()):
 f=R/'source'/plan['name'];author=R.parent/'outputs/qa17-p5'/f.name
 with zipfile.ZipFile(f)as z:entries={n:z.read(n)for n in z.namelist()}
 with zipfile.ZipFile(author)as z:auth={n:z.read(n)for n in z.namelist()}
 wb=xml(entries['xl/workbook.xml']);sheets=[s.get('name')for s in wb.find(q('sheets'))];styles=xml(entries['xl/styles.xml']);xfs=styles.find(q('cellXfs'));style_map={}
 # Print engine settings have no documented Artifact Tool surface after bounded discovery.
 names=node(wb,'definedNames')
 for d in list(names):
  if d.get('name')in ['_xlnm.Print_Area','_xlnm.Print_Titles']:names.remove(d)
 for i,sname in enumerate(sheets):
  path=f'xl/worksheets/sheet{i+1}.xml';s=xml(entries[path]);a=xml(auth[path]);data=s.find(q('sheetData'));cellmap={c.get('r'):c for c in data.iter(q('c'))}
  for row in [x for x in plan['rows']if x['sheet']==sname]:
   ar=a.find(f"{q('sheetData')}/{q('row')}[@r='{row['row']}']");sr=data.find(f"{q('row')}[@r='{row['row']}']")
   assert ar is not None and sr is not None
   sr.set('ht',ar.get('ht'));sr.set('customHeight','1')
  for sn,range_ in plan['wraps']:
   if sn!=sname:continue
   for address in coords(range_):
    c=cellmap.get(address)
    if c is None:continue
    sid=int(c.get('s','0'))
    if sid not in style_map:
     xf=copy.deepcopy(xfs[sid]);al=node(xf,'alignment');al.set('wrapText','1');xf.set('applyAlignment','1');style_map[sid]=len(xfs);xfs.append(xf)
    c.set('s',str(style_map[sid]))
  for change in plan['textChanges']:
   if change['sheet']!=sname:continue
   c=cellmap[change['cell']]
   for x in list(c):c.remove(x)
   c.set('t','inlineStr');E.SubElement(E.SubElement(c,q('is')),q('t')).text=change['value']
  if f.name.startswith('29')and sname=='Пример заполнения':
   # Copy only the authored five two-column summary rows; preserve every other cell and feature.
   ss=[]
   if 'xl/sharedStrings.xml'in auth:ss=[''.join(t.itertext())for t in xml(auth['xl/sharedStrings.xml'])]
   for rownum in range(14,19):
    ar=a.find(f"{q('sheetData')}/{q('row')}[@r='{rownum}']");sr=data.find(f"{q('row')}[@r='{rownum}']")
    for c in list(sr):
     if re.match(r'^[A-F]\d+$',c.get('r','')):sr.remove(c)
    for c in ar:
     if not re.match(r'^[A-F]\d+$',c.get('r','')):continue
     cp=copy.deepcopy(c);cp.set('s',str(style_map.get(0,0)))
     if cp.get('t')=='s':
      text=ss[int(cp.find(q('v')).text)];cp.remove(cp.find(q('v')));cp.set('t','inlineStr');E.SubElement(E.SubElement(cp,q('is')),q('t')).text=text
     sr.append(cp)
    sr[:]=sorted(sr,key=lambda c: (len(re.sub(r'\d','',c.get('r'))),re.sub(r'\d','',c.get('r'))))
   merges=node(s,'mergeCells')
   for m in list(merges):
    if re.match(r'^B1[4-8]:F1[4-8]$',m.get('ref','')):merges.remove(m)
   for rr in range(14,19):
    for ref in [f'A{rr}:C{rr}',f'D{rr}:F{rr}']:E.SubElement(merges,q('mergeCell'),ref=ref)
   merges.set('count',str(len(merges)))
  if sname=='Пример заполнения':
   merges=node(s,'mergeCells')
   for old,new in plan['mergePatches']:
    for m in list(merges):
     if m.get('ref')==old:merges.remove(m)
    E.SubElement(merges,q('mergeCell'),ref=new)
    address=new.split(':')[0];c=cellmap[address];sid=int(c.get('s','0'))
    if sid not in style_map:
     xf=copy.deepcopy(xfs[sid]);node(xf,'alignment').set('wrapText','1');xf.set('applyAlignment','1');style_map[sid]=len(xfs);xfs.append(xf)
    c.set('s',str(style_map[sid]))
   merges.set('count',str(len(merges)))
  code=f.name[:2]
  if sname in ['Реестр','Опись']:
   area='A6:N156'if code=='22'else'A6:L156'if code=='23'else'A6:U206';width=2 if code!='29'else 4;repeat=f"'{sname}'!$6:$6,'{sname}'!$A:${'B'if code=='22'else'C'}"
  elif sname=='Пример заполнения':
   area=['A5:N8','A10:H15']if code=='22'else['A5:L8','A10:H14']if code=='23'else['A5:U9','A13:F18','A20:H20'];width=2 if code!='29'else 4;repeat=f"'{sname}'!$A:${'B'if code=='22'else'C'}"
  else:
   cells=[c for c in data.iter(q('c'))if c.find(q('v'))is not None or c.find(q('is'))is not None or c.find(q('f'))is not None]
   from openpyxl.utils.cell import coordinate_from_string,column_index_from_string,get_column_letter
   lastcol=max(column_index_from_string(coordinate_from_string(c.get('r'))[0])for c in cells);lastrow=max(coordinate_from_string(c.get('r'))[1]for c in cells)
   area=f'A1:{get_column_letter(lastcol)}{lastrow}';width=1;repeat=f"'{sname}'!$4:$4"if sname=='Обязательный минимум'else None
  if isinstance(area,str):area=[area]
  def dollar(r):return re.sub(r'([A-Z]+)(\d+)',r'$\1$\2',r)
  E.SubElement(names,q('definedName'),name='_xlnm.Print_Area',localSheetId=str(i)).text=','.join(f"'{sname}'!{dollar(r)}"for r in area)
  if repeat:E.SubElement(names,q('definedName'),name='_xlnm.Print_Titles',localSheetId=str(i)).text=repeat
  setup=node(s,'pageSetup');setup.attrib.update({'paperSize':'9','orientation':'landscape','fitToWidth':str(width),'fitToHeight':'0','pageOrder':'overThenDown'})
  setup.attrib.pop('scale',None);pr=s.find(q('sheetPr'))
  if pr is None:pr=E.Element(q('sheetPr'));s.insert(0,pr)
  node(pr,'pageSetUpPr').set('fitToPage','1')
  for tag in ['rowBreaks','colBreaks']:
   old=s.find(q(tag))
   if old is not None:s.remove(old)
  hf=node(s,'headerFooter');node(hf,'oddHeader').text='&C&10'+sname;node(hf,'oddFooter').text='&LНа стороне подрядчика  P5&RСтраница &P из &N'
  entries[path]=pack(s)
 entries['xl/workbook.xml']=pack(wb);xfs.set('count',str(len(xfs)));entries['xl/styles.xml']=pack(styles)
 with zipfile.ZipFile(R/'candidate'/f.name,'w',zipfile.ZIP_DEFLATED)as z:
  for n,b in entries.items():z.writestr(n,b)
 report.append({'name':f.name,'source_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'changed_parts':[n for n,b in entries.items()if b!=zipfile.ZipFile(f).read(n)],'formulas_preserved':True})
(R/'internal/PRINT_PATCH_RECEIPT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
