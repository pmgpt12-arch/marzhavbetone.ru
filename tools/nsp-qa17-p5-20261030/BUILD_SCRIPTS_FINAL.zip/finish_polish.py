from pathlib import Path
from docx import Document
R=Path(__file__).resolve().parent
for prefix in ['12','13','16','17','18','21']:
 f=next((R/'candidate').glob(prefix+'-*.docx')); d=Document(f)
 for p in d.paragraphs:
  if prefix=='12' and p.text.startswith('4. Дальше — по файлу'):
   p.text='4. Дальше — по алгоритму 07 «Проверка удержаний»: сопоставьте основание, сумму и доказательства; подготовьте подходящий ответ по формам 14, 15 или 20 этого комплекта.'
  if (prefix=='18' and p.text.strip()=='АКТ ПЕРЕДАЧИ ФРОНТА РАБОТ') or (prefix=='21' and p.text.strip()=='РЕГЛАМЕНТ ФИКСАЦИИ НЕДОСТАТКОВ РАБОТ'):
   p.paragraph_format.page_break_before=True
 def font(ps):
  for p in ps:
   for r in p.runs:r.font.name='Arial'
 font(d.paragraphs)
 for t in d.tables:
  for row in t.rows:
   for c in row.cells:font(c.paragraphs)
 d.save(f)
print('Final typography, form page starts and internal reference corrected')
