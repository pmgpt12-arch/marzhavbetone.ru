from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parent;I=R/'internal';m=json.loads((I/'REVIEW_MANIFEST.json').read_text());H=lambda b:hashlib.sha256(b).hexdigest()
refs=[{'name':m['archive']['name'],'library_file_id':'libfile_f79eca340530819181f045bae15c0ff7','sha256':m['archive']['sha256']},{'name':m['preview']['name'],'library_file_id':'libfile_5f202ea772988191b3152f095f55de53','sha256':m['preview']['sha256']}]
(I/'LIBRARY_ARTIFACT_REFS.json').write_text(json.dumps(refs,indent=2))
m['artifact_refs']=refs;(I/'REVIEW_MANIFEST.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
(I/'RESOLUTION_RECEIPT.json').write_text(json.dumps({'runtime_recovered':True,'source_pinned':m['source_archive_sha256'],'print_defects_closed':['22/23/29 example content fully printed in vertically stacked panels with stable identifiers','06 full graph on one A4 landscape page','10 signature on letter page','Word heading and trailing blank page cleanup'],'preservation':{'formulas':True,'formula_caches':True,'validation':True,'conditional_formatting':True,'working_sheet_values_except_29_D9':True,'04_05_07_bytes':True},'native_office_run':False,'owner_approval':'PENDING','production_changed':False,'full_qa_pass':False,'next_action':'Owner review exact 30-file ZIP; no P5 publication until accepted'},ensure_ascii=False,indent=2))
p=I/'FINAL_TRANSFER.zip'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 z.write(R/'output'/m['archive']['name'],m['archive']['name'])
 for f in R.glob('*.py'):z.write(f,'scripts/'+f.name)
 for f in I.glob('*.json'):z.write(f,'internal/'+f.name)
 for n in ['edit.mjs','build_examples.mjs']:
  f=Path('/tmp/nsp-p5-artifact')/n
  if f.exists():z.write(f,'scripts/'+n)
 for f in (R/'outputs/qa17-p5').glob('example-*.xlsx'):z.write(f,'artifact-authored/'+f.name)
print(json.dumps({'bytes':p.stat().st_size,'sha256':H(p.read_bytes())}))
