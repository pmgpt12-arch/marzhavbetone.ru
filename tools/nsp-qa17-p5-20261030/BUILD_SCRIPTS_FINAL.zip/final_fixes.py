from pathlib import Path
from docx import Document
from lxml import etree as E
import zipfile,json
R=Path(__file__).resolve().parent
for code in ['13','16','17']:
 f=next((R/'candidate').glob(code+'-*.docx'));d=Document(f);changed=0
 for p in d.paragraphs:
  if code=='16'and p.text.startswith('Зафиксировать предупреждение о том, что предоставленный материал'):
   p.text='Зафиксировать фактическое основание предупреждения и приостановку затронутых работ. При обстоятельствах пункта 1 статьи 716 ГК РФ подрядчик немедленно предупреждает заказчика и приостанавливает работы до указаний. В случаях пункта 2 этой статьи он утрачивает право ссылаться на соответствующие обстоятельства. Сохраните доказательства содержания предупреждения, его доставки и принятых мер.';changed+=1
  if code=='17'and p.text.startswith('Получив претензию: зафиксируйте дату'):
   p.text='Получив претензию, зафиксируйте дату и способ получения, определите договорный срок ответа. Сверьте факты и суммы с документами, изложите подтверждённую позицию письменно. Согласование осмотра или запроса сведений само по себе не означает признания причин дефекта и размера требования.';changed+=1
 if code=='13':
  for t in d.tables:
   for row in t.rows:
    for c in row.cells:
     if 'повреждение после допуска — зона допустившего'in c.text:
      c.text='при допуске третьих лиц фиксируются дата, участники и состояние зоны; причину повреждения и ответственность устанавливают по договору и доказательствам';changed+=1
 assert changed==1,(code,changed);d.save(f)
# Metadata-only correction of the unchanged 06 content: its right-hand columns spilled onto a second page.
f=next((R/'candidate').glob('06-*.xlsx'));q=lambda n:'{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'+n
with zipfile.ZipFile(R/'source'/f.name)as z:e={n:z.read(n)for n in z.namelist()}
w=E.fromstring(e['xl/workbook.xml']);dn=w.find(q('definedNames'))
if dn is None:dn=E.Element(q('definedNames'));cp=w.find(q('calcPr'));w.insert(list(w).index(cp)if cp is not None else len(w),dn)
for d in list(dn):
 if d.get('name')in ['_xlnm.Print_Area','_xlnm.Print_Titles']:dn.remove(d)
E.SubElement(dn,q('definedName'),name='_xlnm.Print_Area',localSheetId='0').text="'График возмещения'!$A$1:$G$11"
s=E.fromstring(e['xl/worksheets/sheet1.xml']);pr=s.find(q('sheetPr'))
if pr is None:pr=E.Element(q('sheetPr'));s.insert(0,pr)
ps=pr.find(q('pageSetUpPr'))
if ps is None:ps=E.SubElement(pr,q('pageSetUpPr'))
ps.set('fitToPage','1');setup=s.find(q('pageSetup'))
if setup is None:setup=E.SubElement(s,q('pageSetup'))
setup.attrib.update({'orientation':'landscape','paperSize':'9','fitToWidth':'1','fitToHeight':'1'});setup.attrib.pop('scale',None)
e['xl/workbook.xml']=E.tostring(w,xml_declaration=True,encoding='UTF-8',standalone=True);e['xl/worksheets/sheet1.xml']=E.tostring(s,xml_declaration=True,encoding='UTF-8',standalone=True)
with zipfile.ZipFile(f,'w',zipfile.ZIP_DEFLATED)as z:
 for n,b in e.items():z.writestr(n,b)
print('Final accuracy and 06 print fixes applied')
