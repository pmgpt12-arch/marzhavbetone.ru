import fs from 'node:fs/promises';
import {FileBlob,SpreadsheetFile} from '@oai/artifact-tool';
const root='/workspace/scratch/1c70cef937ec/qa17-p5';const outputDir='/workspace/scratch/1c70cef937ec/outputs/qa17-p5';await fs.mkdir(outputDir,{recursive:true});
const plans={
'22':{'Реестр':[[6,60]],'Сводка':[[1,30],[2,42],[4,34],[5,34],[6,34],[7,34],[8,42],[9,34],[10,34],[11,34],[12,40],[13,36],[14,36],[15,36],[16,36],[17,36],[18,36],[19,36],[20,36],[21,45]],'Пример заполнения':[[5,60],[6,52],[7,52],[8,64],[10,50],[13,50],[14,30],[15,50]]},
'23':{'Реестр':[[6,60]],'Сводка':[[1,30],[2,42],[4,38],[5,50],[6,38],[7,55],[8,38],[9,38],[10,38],[11,38],[12,38],[13,38],[14,38],[15,38],[16,38],[17,38],[18,38],[19,38],[20,38],[21,38],[22,38],[23,38],[24,38],[25,38],[26,45]],'Виды':[[11,50]],'Пример заполнения':[[5,60],[6,65],[7,60],[8,60],[10,70],[13,45],[14,50]]},
'29':{'Спорная зона':[[1,32],[2,42],[3,58],[4,40],[5,40],[6,54],[7,45],[8,54],[9,40],[10,48],[11,65],[12,65],[13,65],[14,65],[16,85]],'Опись':[[6,72]],'Обязательный минимум':[[1,32],[2,55],[4,55]],'Сводка':[[1,32],[2,50],[4,40],[5,40],[6,40],[7,40],[8,55],[9,55],[10,55],[11,55],[12,55],[13,55],[15,75],[17,70]],'Виды':[[2,50],[25,80]],'Пример заполнения':[[5,72],[6,90],[7,90],[8,90],[9,90],[11,100],[14,45],[15,45],[16,45],[17,45],[18,60],[20,80]]}
};
const files=await fs.readdir(root+'/source');let manifest=[];
for(const code of Object.keys(plans)){
 const name=files.find(n=>n.startsWith(code)&&n.endsWith('.xlsx'));const w=await SpreadsheetFile.importXlsx(await FileBlob.load(root+'/source/'+name));
 let rows=[];for(const [sheetName,rs]of Object.entries(plans[code])){
  const s=w.worksheets.getItem(sheetName);for(const [r,height]of rs){s.getRange(`A${r}:U${r}`).format.rowHeight=height;rows.push({sheet:sheetName,row:r,height});}
 }
 const wraps=code==='22'?[['Пример заполнения','A13:A15'],['Сводка','A1:D21']]:code==='23'?[['Сводка','A1:D26']]:[['Спорная зона','A1:D16'],['Сводка','A1:D17'],['Пример заполнения','A14:A18']];
 for(const [sn,range]of wraps)w.worksheets.getItem(sn).getRange(range).format.wrapText=true;
 const mergePatches=code==='22'?[['A10:N10','A10:H10']]:code==='23'?[['A10:L10','A10:H10'],['A14:L14','A14:H14']]:[['A20:U20','A20:H20']];const ex=w.worksheets.getItem('Пример заполнения');for(const [old,next]of mergePatches){ex.unmergeCells(old);ex.mergeCells(next);ex.getRange(next).format.wrapText=true;}
 let textChanges=[];
 if(code==='29'){const ex=w.worksheets.getItem('Пример заполнения');for(let r=14;r<=18;r++){const label=ex.getRange(`A${r}`).values[0][0],value=ex.getRange(`B${r}`).values[0][0];ex.unmergeCells(`B${r}:F${r}`);ex.getRange(`A${r}:F${r}`).clear({applyTo:'contents'});ex.mergeCells(`A${r}:C${r}`);ex.getRange(`A${r}`).values=[[label]];ex.mergeCells(`D${r}:F${r}`);ex.getRange(`D${r}`).values=[[value]];} const s=w.worksheets.getItem('Сводка');s.getRange('D9').values=[['Сохраните подтверждение передачи; его отсутствие само по себе не доказывает, что документ не передан.']];textChanges.push({sheet:'Сводка',cell:'D9',value:s.getRange('D9').values[0][0]});}
 w.recalculate();const inspect=await w.inspect({kind:'table',range:(code==='29'?'Сводка':'Пример заполнения')+'!A1:H18',include:'values,formulas',tableMaxRows:18,tableMaxCols:8});await fs.writeFile(root+'/internal/'+code+'-author-inspect.json',inspect.ndjson);
 const out=await SpreadsheetFile.exportXlsx(w);await out.save(outputDir+'/'+name);manifest.push({name,rows,wraps,textChanges,mergePatches});
 console.log('AUTHORED',code);
}
await fs.writeFile(root+'/internal/XLSX_AUTHORED_PLAN.json',JSON.stringify(manifest,null,2));
