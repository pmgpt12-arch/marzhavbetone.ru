from pathlib import Path
import zipfile,json,hashlib,datetime
R=Path(__file__).resolve().parent;I=R/'internal';O=R/'output';H=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((I/'REVIEW_MANIFEST.json').read_text());assert m['check_count']==542
p=O/'P5_Uderzhaniya_shtrafy_zachety_v1.zip'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted((R/'candidate').iterdir()):
  info=zipfile.ZipInfo(f.name,(2026,10,30,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,f.read_bytes())
with zipfile.ZipFile(p)as z:
 assert len(z.namelist())==30 and z.testzip() is None
 assert all(H(z.read(x['name']))==x['sha256']for x in m['files'])
receipt={'status':'VISUAL_REVIEW_COMPLETED','pages':m['rendered_pages'],'representatives':m['visual_representatives'],'review_basis':'All representative contact sheets visually inspected; changed Word pages re-inspected after final render; pixel-identical register continuations covered by exact bitmap comparison excluding page-number footer.','limitations':'LibreOffice render only; no new native Microsoft Office test. Not FULL_QA_PASS.','preview_sha256':m['preview']['sha256'],'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'contacts':[{'name':Path(x).name,'sha256':H(Path(x).read_bytes())}for x in m['visual_contacts']]}
(I/'VISUAL_REVIEW_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
m.update(status='READY_FOR_OWNER_REVIEW',archive={'name':p.name,'bytes':p.stat().st_size,'sha256':H(p.read_bytes())},visual_review=receipt)
(I/'REVIEW_MANIFEST.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
print(json.dumps({'archive':m['archive'],'preview':m['preview'],'pages':m['rendered_pages']},ensure_ascii=False))
