from pathlib import Path
import json,hashlib,zipfile,re,copy
from collections import Counter
from lxml import etree as E
from openpyxl import load_workbook
from docx import Document
from docx.oxml.ns import qn
import fitz
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;O=R/'candidate';I=R/'internal';checks=[]
H=lambda b:hashlib.sha256(b).hexdigest()
def check(name,ok):
 if not ok:raise AssertionError(name)
 checks.append({'name':name,'status':'PASS'})
files=sorted(O.iterdir());check('30 buyer files',len(files)==30);check('exact format composition',Counter(f.suffix for f in files)=={'.docx':22,'.xlsx':6,'.pdf':2});check('single PDF start guide',[f.name for f in files if f.name.startswith('00-')]==['00-START-HERE.pdf'])
check('unchanged calculation workbook04',H((O/'04-raschet-ubytkov.xlsx').read_bytes())==H((R/'source/04-raschet-ubytkov.xlsx').read_bytes()));check('unchanged register05',H((O/'05-reestr-uderzhaniy.xlsx').read_bytes())==H((R/'source/05-reestr-uderzhaniy.xlsx').read_bytes()));check('unchanged algorithm07',H((O/'07-algoritm-proverki-uderzhaniy.pdf').read_bytes())==H((R/'source/07-algoritm-proverki-uderzhaniy.pdf').read_bytes()))
q=lambda n:'{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'+n
for f in sorted(O.glob('*.xlsx')):
 before=load_workbook(R/'source'/f.name);after=load_workbook(f);check(f.name+' worksheet identities',before.sheetnames==after.sheetnames)
 for bs,as_ in zip(before,after):
  bf={c.coordinate:c.value for row in bs for c in row if c.data_type=='f'};af={c.coordinate:c.value for row in as_ for c in row if c.data_type=='f'};check(f.name+'/'+bs.title+' all actual formulas unchanged',bf==af)
  if bs.title!='Пример заполнения':
   changes={c.coordinate:(c.value,as_[c.coordinate].value)for row in bs for c in row if c.value!=as_[c.coordinate].value};allowed={'D9'}if f.name.startswith('29')and bs.title=='Сводка'else set();check(f.name+'/'+bs.title+' scoped values',set(changes)<=allowed)
 with zipfile.ZipFile(R/'source'/f.name)as bz,zipfile.ZipFile(f)as az:
  check(f.name+' CRC',az.testzip()is None)
  for part in [n for n in bz.namelist()if re.match(r'xl/worksheets/sheet\d+.xml$',n)]:
   b=E.fromstring(bz.read(part));a=E.fromstring(az.read(part))
   for tag in ['dataValidations','conditionalFormatting','autoFilter']:
    check(f.name+'/'+part+'/'+tag+' preserved',[E.tostring(x)for x in b.findall(q(tag))]==[E.tostring(x)for x in a.findall(q(tag))])
   # Formula caches, as well as formula text, must survive the formatting operation.
   bv={c.get('r'):E.tostring(c.find(q('v')))if c.find(q('v'))is not None else None for c in b.iter(q('c'))if c.find(q('f'))is not None};av={c.get('r'):E.tostring(c.find(q('v')))if c.find(q('v'))is not None else None for c in a.iter(q('c'))if c.find(q('f'))is not None};check(f.name+'/'+part+' formula caches preserved',bv==av)
for f in sorted(O.glob('*.docx')):
 d=Document(f)
 for i,t in enumerate(d.tables):
  check(f.name+f' table{i+1} width',t._tbl.tblPr.find(qn('w:tblW')).get(qn('w:w'))=='9866')
  check(f.name+f' table{i+1} grid',sum(int(c.get(qn('w:w')))for c in t._tbl.tblGrid)==9866)
 check(f.name+' unprotected editable',not d.settings.element.xpath('./w:documentProtection[@w:enforcement="1"]'))
for n in ['01','02','03','10']:
 d=Document(next(O.glob(n+'*.docx')));check(n+' separate address and signature blocks',len(d.tables)>=2)
form=Document(next(O.glob('13-*.docx')));text='\n'.join(p.text for p in form.paragraphs);check('13 actual editable agreement appended','№ {{НОМЕР_СОГЛАШЕНИЯ}}'in text and '6. Соглашение действует'in text)
# Full preview from the exact final files and their final print views.
preview=fitz.open();mapping=[];sources=[]
for f in files:
 p=f if f.suffix=='.pdf'else (R/'render-word'/f.stem/(f.stem+'.pdf')if f.suffix=='.docx'else R/'render-excel'/(f.stem+'.pdf'))
 check(f.name+' rendered PDF exists',p.is_file());d=fitz.open(p);check(f.name+' no empty PDF pages',all(len(x.get_text().strip())>0 for x in d))
 start=len(preview)+1;preview.insert_pdf(d);mapping.append({'file':f.name,'from_page':start,'pages':len(d),'source_sha256':H(f.read_bytes()),'render_pdf_sha256':H(p.read_bytes())});sources.append((f,p))
# All original example labels and values must survive printing after rearrangement.
for m in json.loads((I/'EXAMPLE_LAYOUT_MANIFEST.json').read_text()):
 p=R/'render-excel'/(Path(m['sourceFilename']).stem+'.pdf');d=fitz.open(p);txt=''.join(x.get_text()for x in d);norm=lambda x:re.sub(r'\s+','',str(x)).replace('\u00ad','')
 for item in set(m['content']):
  if item:check(m['code']+' printed example content: '+item[:42],norm(item)in norm(txt))
# Render all pages. Pixel-identical blank register continuations are reviewed by representative.
visual=I/'visual-final';visual.mkdir(exist_ok=True);representatives=[];seen={};coverage=[]
for f,p in sources:
 d=fitz.open(p)
 for i,page in enumerate(d):
  pix=page.get_pixmap(matrix=fitz.Matrix(1,1));im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
  # Remove only the bottom margin containing page numbering when testing exact repeated layout.
  crop=im.crop((0,0,im.width,max(1,im.height-32)));key=(f.name,H(crop.tobytes()));
  if key not in seen:
   dest=visual/f'{f.stem}-{i+1}.png';im.save(dest);seen[key]=str(dest);representatives.append((f.name,i+1,dest,im.copy()))
  coverage.append({'file':f.name,'page':i+1,'representative':seen[key],'pixel_equal_except_footer':True})
# Six portrait pages or four landscape pages per montage, without scaling page pixels.
portraits=[x for x in representatives if x[3].height>x[3].width];landscapes=[x for x in representatives if x[3].height<=x[3].width]
contacts=[]
for kind,items,n,cols in [('word',portraits,6,3),('excel',landscapes,4,2)]:
 for start in range(0,len(items),n):
  chunk=items[start:start+n];cw=max(x[3].width for x in chunk)+12;ch=max(x[3].height for x in chunk)+27;rows=(len(chunk)+cols-1)//cols;canvas=Image.new('RGB',(cols*cw,rows*ch),'#d5d5d5');draw=ImageDraw.Draw(canvas)
  for j,(name,pg,_,im)in enumerate(chunk):
   xx=(j%cols)*cw;yy=(j//cols)*ch;draw.text((xx+3,yy+4),name[:48]+' p'+str(pg),fill='black');canvas.paste(im,(xx,yy+24))
  dest=visual/f'{kind}-contact-{start//n+1}.png';canvas.save(dest);contacts.append(str(dest))
out=R/'output';out.mkdir(exist_ok=True);preview_path=out/f'P5_predprosmotr_{len(preview)}str.pdf';preview.save(preview_path,garbage=4,deflate=True)
manifest={'schema':'NSP_QA17_P5_OWNER_REVIEW_v1','sku':'p5','edition':'P5-layout-v1','status':'AWAITING_FINAL_VISUAL_REVIEW','owner_approval':'PENDING','release_allowed':False,'production_changed':False,'full_qa_pass':False,'new_native_office_test_performed':False,'source_archive_sha256':H((R/'source.zip').read_bytes()),'file_count':30,'formats':{'docx':22,'xlsx':6,'pdf':2},'checks':checks,'check_count':len(checks),'render_engine':'LibreOffice; no new native Microsoft Office run','rendered_pages':len(preview),'render_map':mapping,'visual_representatives':len(representatives),'visual_contacts':contacts,'visual_coverage':coverage,'preview':{'name':preview_path.name,'sha256':H(preview_path.read_bytes())},'files':[{'name':f.name,'bytes':f.stat().st_size,'sha256':H(f.read_bytes())}for f in files]}
(I/'REVIEW_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print(json.dumps({'checks':len(checks),'pages':len(preview),'representatives':len(representatives),'contacts':contacts},ensure_ascii=False))
