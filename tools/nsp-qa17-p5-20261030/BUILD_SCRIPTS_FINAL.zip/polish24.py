from pathlib import Path
from docx import Document
from docx.shared import Pt
f=next((Path(__file__).resolve().parent/'candidate').glob('24-*.docx'));d=Document(f)
for p in d.paragraphs[54:]:p.paragraph_format.space_after=Pt(1)
d.save(f)
