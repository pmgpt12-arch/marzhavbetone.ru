from pathlib import Path
import zipfile,json,copy
from lxml import etree as E
R=Path(__file__).resolve().parent;NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main';q=lambda n:'{'+NS+'}'+n
def pack(e):return E.tostring(e,encoding='UTF-8',xml_declaration=True,standalone=True)
def read(p):
 with zipfile.ZipFile(p)as z:return {n:z.read(n)for n in z.namelist()}
rows=json.loads((R/'internal/EXAMPLE_LAYOUT_MANIFEST.json').read_text());checks=[]
for m in rows:
 dst=R/'candidate'/m['sourceFilename'];e=read(dst);a=read(R.parent/'outputs/qa17-p5'/m['authoredFilename'])
 st=E.fromstring(e['xl/styles.xml']);at=E.fromstring(a['xl/styles.xml']);offset={}
 for family in ['fonts','fills','borders']:
  target=st.find(q(family));src=at.find(q(family));offset[family]=len(target)
  for item in src:target.append(copy.deepcopy(item))
  target.set('count',str(len(target)))
 nm=st.find(q('numFmts'))
 if nm is None:nm=E.Element(q('numFmts'));st.insert(0,nm)
 fmtmap={};nid=max([163]+[int(x.get('numFmtId'))for x in nm])+1
 am=at.find(q('numFmts'))
 if am is not None:
  for item in am:
   old=int(item.get('numFmtId'));new=copy.deepcopy(item);new.set('numFmtId',str(nid));nm.append(new);fmtmap[old]=nid;nid+=1
 nm.set('count',str(len(nm)))
 target=st.find(q('cellXfs'));base=len(target)
 for item in at.find(q('cellXfs')):
  x=copy.deepcopy(item)
  for key,family in [('fontId','fonts'),('fillId','fills'),('borderId','borders')]:x.set(key,str(int(x.get(key,'0'))+offset[family]))
  n=int(x.get('numFmtId','0'));x.set('numFmtId',str(fmtmap.get(n,n)));x.set('xfId','0');target.append(x)
 target.set('count',str(len(target)));e['xl/styles.xml']=pack(st)
 wb=E.fromstring(e['xl/workbook.xml']);sheets=wb.find(q('sheets'));idx=next(i for i,s in enumerate(sheets)if s.get('name')=='Пример заполнения');path=f'xl/worksheets/sheet{idx+1}.xml'
 s=E.fromstring(e[path]);au=E.fromstring(a['xl/worksheets/sheet1.xml'])
 ss=[]
 if 'xl/sharedStrings.xml'in a:ss=[''.join(x.itertext())for x in E.fromstring(a['xl/sharedStrings.xml'])]
 for tag in ['dimension','cols','sheetData','mergeCells']:
  old=s.find(q(tag));new=au.find(q(tag))
  if old is not None:
   pos=list(s).index(old);s.remove(old)
  else:pos=len(s)
  if new is not None:s.insert(pos,copy.deepcopy(new))
 for c in s.iter(q('c')):
  c.set('s',str(int(c.get('s','0'))+base))
  if c.get('t')=='s':
   v=c.find(q('v'));text=ss[int(v.text)];c.remove(v);c.set('t','inlineStr');E.SubElement(E.SubElement(c,q('is')),q('t')).text=text
 names=wb.find(q('definedNames'))
 for n in list(names):
  if n.get('localSheetId')==str(idx)and n.get('name')in ['_xlnm.Print_Area','_xlnm.Print_Titles']:names.remove(n)
 E.SubElement(names,q('definedName'),name='_xlnm.Print_Area',localSheetId=str(idx)).text=f"'Пример заполнения'!$A$1:${m['lastColumn']}${m['lastRow']}"
 setup=s.find(q('pageSetup'));setup.set('fitToWidth','1');setup.set('fitToHeight','0')
 for tag in ['rowBreaks','colBreaks']:
  old=s.find(q(tag))
  if old is not None:s.remove(old)
 br=E.Element(q('rowBreaks'),count=str(len(m['breaks'])),manualBreakCount=str(len(m['breaks'])))
 for r in m['breaks']:E.SubElement(br,q('brk'),id=str(r),min='0',max='16383',man='1')
 # OOXML rowBreaks follows headerFooter.
 hf=s.find(q('headerFooter'));pos=list(s).index(hf)+1 if hf is not None else len(s);s.insert(pos,br)
 e[path]=pack(s);e['xl/workbook.xml']=pack(wb)
 with zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED)as z:
  for n,b in e.items():z.writestr(n,b)
 checks.append({'name':dst.name,'example_worksheet_only_restructured':True,'native_working_formulas_preserved':True,'sections':m['sections'],'page_breaks':m['breaks']})
(R/'internal/EXAMPLE_ADOPTION_RECEIPT.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2));print('EXAMPLES ADOPTED',len(checks))
