from pathlib import Path
from lxml import etree as ET
import zipfile, copy, hashlib, re, json, sys
P=Path('/home/denis/projects/nsp-qa14-20261024')
C=Path('/home/denis/.local/share/ai-business-os/tool-sandbox/excel-laptop-preflight-20261011')
src=C/'native/qa14-p2-v10c-named-20261025/p207-v10c.xlsx'
out=P/'qa14-p207-v11-compact-footer-nonrelease.xlsx'
sha='03533acacaa50e4704369c9772c01ec6a0c425c4ca8672e2b9bd388c9e9162d9'
assert hashlib.sha256(src.read_bytes()).hexdigest()==sha
N='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
q=lambda name: '{'+N+'}'+name
with zipfile.ZipFile(src) as z:
    w=ET.fromstring(z.read('xl/workbook.xml'))
    s=ET.fromstring(z.read('xl/worksheets/sheet3.xml'))
    registry=z.read('xl/worksheets/sheet1.xml')
    data=s.find(q('sheetData'))
    original={int(x.get('r')):copy.deepcopy(x) for x in data.findall(q('row'))}
    assert len([i for i in original if 7<=i<=106])==100
    def rowcopy(source,newno):
        r=copy.deepcopy(original[source])
        r.attrib['r']=str(newno)
        r.attrib.pop('hidden',None)
        for c in r.findall(q('c')):
            c.attrib['r']=re.sub(r'\d+$',str(newno),c.attrib['r'])
        return r
    def put_formula(row,col,formula,style=None):
        ref=col+row.get('r')
        c=next((v for v in row.findall(q('c')) if v.get('r')==ref),None)
        if c is None:c=ET.SubElement(row,q('c'),r=ref)
        if style is not None:c.set('s',str(style))
        c.attrib.pop('t',None)
        for x in list(c):c.remove(x)
        ET.SubElement(c,q('f')).text=formula
        return c
    def put_inline(row,col,value,style=None):
        ref=col+row.get('r')
        c=next((v for v in row.findall(q('c')) if v.get('r')==ref),None)
        if c is None:c=ET.SubElement(row,q('c'),r=ref)
        if style is not None:c.set('s',str(style))
        c.set('t','inlineStr')
        for x in list(c):c.remove(x)
        ET.SubElement(ET.SubElement(c,q('is')),q('t')).text=value
        return c
    def item_expr(col,rowno):
        ix='$K'+str(rowno)
        v="INDEX('Реестр'!$%s$4:$%s$103,%s)"%(col,col,ix)
        return 'IF(%s="","",%s)'%(v,v)
    def footer_expr(rowno,which):
        n='$K$3'
        test=lambda v:'ROW()='+n+'+'+str(v)
        if which=='B':
            clauses=[(5,'"ИТОГО"'),(6,'"ПОДРЯДЧИК"'),(7,'"Должн./ФИО:"'),(8,'"Подпись:"')]
        elif which=='C':
            clauses=[(7,'"________________"'),(8,'"________________"')]
        elif which=='D':
            clauses=[(8,'"Дата:"')]
        elif which=='E':
            clauses=[(8,'"____________"')]
        elif which=='F':
            clauses=[(5,"'Реестр'!F104")]
        elif which=='G':
            clauses=[(6,'"ЗАКАЗЧИК"'),(7,'"Должн./ФИО:"'),(8,'"Подпись:"')]
        elif which=='H':
            clauses=[(7,'"________________"'),(8,'"________________"')]
        elif which=='I':
            clauses=[(5,"'Реестр'!I104"),(8,'"Дата:"')]
        elif which=='J':
            clauses=[(8,'"____________"')]
        else:clauses=[]
        result='""'
        for k,text in reversed(clauses):
            result='IF(%s,%s,%s)'%(test(k),text,result)
        return result
    for child in list(data):data.remove(child)
    for rn in [1,2]:
        data.append(rowcopy(rn,rn))
    status=rowcopy(3,3)
    for c in list(status.findall(q('c'))):
        if c.get('r')!='A3':status.remove(c)
    put_formula(status,'A','"Статус: "&\'Реестр\'!A104&"  |  Количество позиций: "&$K$3')
    put_formula(status,'K','COUNT($K$5:$K$104)')
    status.set('ht','28');status.set('customHeight','1')
    data.append(status)
    header=rowcopy(6,4);data.append(header)
    for rn in range(5,109):
        template=7 if rn%2 else 8
        row=rowcopy(template,rn)
        row.set('ht','24');row.set('customHeight','1')
        if rn<=104:
            ktemplate=original[7].find(q('c')+'[@r="K7"]')
            assert ktemplate is not None
            f=ktemplate.find(q('f')).text
            f=f.replace('ROWS($K$7:K7)','ROWS($K$5:K%d)'%rn)
            put_formula(row,'K',f,style=ktemplate.get('s'))
        else:
            for c in list(row.findall(q('c'))):
                if c.get('r')=='K'+str(rn):row.remove(c)
        for col in 'ABCDEFGHIJ':
            if col=='A':
                formula='IF(ISNUMBER($K%d),$K%d,"")'%(rn,rn)
            else:
                formula='IF(ISNUMBER($K%d),%s,%s)'%(rn,item_expr(col,rn),footer_expr(rn,col))
            put_formula(row,col,formula)
        data.append(row)
    assert len(data.findall(q('row')))==108
    for c in s.findall(q('autoFilter')):s.remove(c)
    merges=s.find(q('mergeCells'))
    if merges is not None:
        for child in list(merges):merges.remove(child)
        for addr in ['A1:J1','A2:J2','A3:J3']:
            ET.SubElement(merges,q('mergeCell'),ref=addr)
        merges.set('count','3')
    dimension=s.find(q('dimension'))
    dimension.set('ref','A1:K108')
    setup=s.find(q('pageSetup'))
    setup.set('fitToWidth','1')
    setup.set('fitToHeight','0')
    dn=w.find(q('definedNames'))
    value="OFFSET('Печать'!$A$1,0,0,MAX(8,8+COUNT('Печать'!$K$5:$K$104)),10)"
    cnt=0
    for name in dn.findall(q('definedName')):
        if name.get('name')=='_xlnm.Print_Area' and name.get('localSheetId')=='2':
            name.text=value;cnt+=1
        if name.get('name')=='_xlnm.Print_Titles' and name.get('localSheetId')=='2':
            name.text="'Печать'!$4:$4";cnt+=1
        if name.get('name')=='P2_PRINT_RANGE':
            name.text=value;cnt+=1
    assert cnt==3
    calc=w.find(q('calcPr'))
    if calc is not None:
        calc.set('calcMode','auto')
        calc.set('fullCalcOnLoad','1')
        calc.set('forceFullCalc','1')
    replacements={'xl/worksheets/sheet3.xml':ET.tostring(s,encoding='UTF-8',xml_declaration=False),
                  'xl/workbook.xml':ET.tostring(w,encoding='UTF-8',xml_declaration=False)}
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED) as dst:
        for info in z.infolist():dst.writestr(info,replacements.get(info.filename,z.read(info.filename)))
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    assert z.read('xl/worksheets/sheet1.xml')==registry,'CORE_MODIFIED'
    assert z.read('xl/worksheets/sheet2.xml')==zipfile.ZipFile(src).read('xl/worksheets/sheet2.xml'),'INSTRUCTION_MODIFIED'
    s2=ET.fromstring(z.read('xl/worksheets/sheet3.xml'))
    assert s2.find(q('autoFilter')) is None
    rows=s2.findall('.//'+q('sheetData')+'/'+q('row'))
    assert len(rows)==108 and not any(x.get('hidden')=='1' for x in rows)
    fcount=sum(len(r.findall('.//'+q('f'))) for r in rows)
    reg=ET.fromstring(registry)
    coref=sum(len(r.findall('.//'+q('f'))) for r in reg.findall('.//'+q('sheetData')+'/'+q('row')))
    assert coref==203,coref
    assert fcount>=1000
print(json.dumps({'file':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
'bytes':out.stat().st_size,'core203':'EXACT_XML_PASS','print_formulas':fcount,
'print_rows':108,'autofilter':False,'staged_nonrelease':True},ensure_ascii=False))
