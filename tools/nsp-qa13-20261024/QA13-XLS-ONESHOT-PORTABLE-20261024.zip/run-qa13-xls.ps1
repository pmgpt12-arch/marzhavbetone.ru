$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$work=Join-Path $env:TEMP ('NSP-QA13-XLS-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work -Force | Out-Null
$expected=@{
'01-ks-2.xls'='b09296147561df5afd9a38bbb196860a1a3a3268a8b26d9751c88d4c5bca6281'
'02-ks-3.xls'='d6922089bffcde2a00a30d62d8d7ea1d87676fe4de9ae44a3d0e9af4d821ed0a'
'06-zhurnal-ucheta-rabot-ks-6a.xls'='053c5f1603478ca08fbab8f522ed4448546941d4009c79a76bdc8af13248aa29'
}
$results=New-Object System.Collections.ArrayList
$excel=$null
try {
 $excel=New-Object -ComObject Excel.Application
 $excel.Visible=$false; $excel.DisplayAlerts=$false; $excel.AskToUpdateLinks=$false
 $excel.AutomationSecurity=3
 foreach($name in @('01-ks-2.xls','02-ks-3.xls','06-zhurnal-ucheta-rabot-ks-6a.xls')){
  $book=$null; $saved=$null
  $src=Join-Path $root $name; $dest=Join-Path $work $name
  $item=[ordered]@{file=$name;expected_sha=$expected[$name];status='FAIL';excel_version=[string]$excel.Version;excel_build=[string]$excel.Build;sheet_names=@();sheet_count=0;nonempty_cells=@();pdf_pages='UNVERIFIED';pdf_sha='';saved_sha='';error=''}
  try {
   $before=(Get-FileHash -Algorithm SHA256 -LiteralPath $src).Hash.ToLowerInvariant()
   if($before -ne $expected[$name]){throw 'Original SHA mismatch before test'}
   Copy-Item -LiteralPath $src -Destination $dest
   if((Get-FileHash -Algorithm SHA256 -LiteralPath $dest).Hash.ToLowerInvariant() -ne $expected[$name]){throw 'Copy SHA mismatch'}
   $book=$excel.Workbooks.Open($dest,0,$true)
   $item.sheet_count=[int]$book.Worksheets.Count
   if($item.sheet_count -lt 1){throw 'No worksheets'}
   foreach($sheet in $book.Worksheets){
    $item.sheet_names+=([string]$sheet.Name)
    $used=$sheet.UsedRange
    $count=0
    foreach($cell in $used.Cells){if($null -ne $cell.Value2 -and [string]$cell.Value2 -ne ''){$count++}}
    $item.nonempty_cells+=($count)
   }
   $pdf=Join-Path $work ([IO.Path]::GetFileNameWithoutExtension($name)+'.pdf')
   $book.ExportAsFixedFormat(0,$pdf)
   if(-not (Test-Path -LiteralPath $pdf)){throw 'PDF export missing'}
   $item.pdf_sha=(Get-FileHash -Algorithm SHA256 -LiteralPath $pdf).Hash.ToLowerInvariant()
   $savedPath=Join-Path $work ([IO.Path]::GetFileNameWithoutExtension($name)+'-saved.xlsx')
   $book.SaveAs($savedPath,51)
   $book.Close($false);$book=$null
   $saved=$excel.Workbooks.Open($savedPath,0,$true)
   if($saved.Worksheets.Count -ne $item.sheet_count){throw 'Reopen sheet count mismatch'}
   $saved.Close($false);$saved=$null
   $item.saved_sha=(Get-FileHash -Algorithm SHA256 -LiteralPath $savedPath).Hash.ToLowerInvariant()
   if((Get-FileHash -Algorithm SHA256 -LiteralPath $src).Hash.ToLowerInvariant() -ne $expected[$name]){throw 'Original changed'}
   if((Get-FileHash -Algorithm SHA256 -LiteralPath $dest).Hash.ToLowerInvariant() -ne $expected[$name]){throw 'XLS copy changed'}
   if($item.nonempty_cells.Count -ne $item.sheet_count){throw 'Content count mismatch'}
   $item.status='NATIVE_PASS_VISUAL_PENDING'
  } catch {$item.error=$_.Exception.ToString()} finally {
   if($saved){try{$saved.Close($false)}catch{}}
   if($book){try{$book.Close($false)}catch{}}
  }
  [void]$results.Add([pscustomobject]$item)
 }
} finally {
 if($excel){try{$excel.Quit()}catch{}}
 [GC]::Collect();[GC]::WaitForPendingFinalizers()
}
$receipt=[ordered]@{scope='QA13_XLS_ONESHOT_NATIVE_ONLY';generated=(Get-Date).ToString('o');workdir=$work;results=@($results);original_sha_after=@{}}
foreach($name in $expected.Keys){$receipt.original_sha_after[$name]=(Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $root $name)).Hash.ToLowerInvariant()}
$receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $work 'native-receipt.json') -Encoding UTF8
Write-Host ('QA13_RESULT_DIR='+$work)
Write-Host ('QA13_RECEIPT='+ (Join-Path $work 'native-receipt.json'))
Write-Host ('QA13_NATIVE_STATUS='+ (($results | ForEach-Object {$_.file+':'+$_.status}) -join ';'))
Write-Host 'VISUAL_REVIEW_REQUIRED: inspect every page of three exported PDFs before full PASS'
