from pathlib import Path
import copy,hashlib,json,zipfile
import xml.etree.ElementTree as E
ROOT=Path(__file__).resolve().parent
Q='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}';NS={'s':Q[1:-1]}
E.register_namespace('',Q[1:-1])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 pas=json.loads((ROOT/'passport.json').read_text());approval=json.loads((ROOT/'style-acceptance.json').read_text())
 assert approval['verdict']=='ACCEPT_STYLE_ONLY_WITH_PRINT_STOP' and approval['head']==pas['source']['head']
 source=ROOT.parent/pas['source']['path'];assert sha(source)==pas['source']['sha256']
 out=ROOT/'63-reestr-zatrat-po-obektu-Business_Print_candidate.xlsx';changed={}
 with zipfile.ZipFile(source) as a:
  for index,name in enumerate(pas['print_contract'],1):
   part=f'xl/worksheets/sheet{index}.xml';root=E.fromstring(a.read(part));contract=pas['print_contract'][name]
   prop=root.find('s:sheetPr',NS)
   if prop is None:prop=E.Element(Q+'sheetPr');root.insert(0,prop)
   ps=prop.find('s:pageSetUpPr',NS)
   if ps is None:ps=E.SubElement(prop,Q+'pageSetUpPr')
   ps.set('fitToPage','1')
   setup=root.find('s:pageSetup',NS)
   if setup is None:
    setup=E.Element(Q+'pageSetup');margin=root.find('s:pageMargins',NS)
    root.insert(list(root).index(margin)+1 if margin is not None else len(root),setup)
   setup.attrib.update({'paperSize':'8' if contract['paper']=='A3' else '9','orientation':contract['orientation'],'fitToWidth':'1','fitToHeight':'0'})
   changed[part]=E.tostring(root,encoding='utf-8')
  workbook=E.fromstring(a.read('xl/workbook.xml'));names=workbook.find('s:definedNames',NS)
  if names is None:
   names=E.Element(Q+'definedNames');calc=workbook.find('s:calcPr',NS);workbook.insert(list(workbook).index(calc) if calc is not None else len(workbook),names)
  for index,name in enumerate(pas['print_contract']):
   area="'"+name+"'!"+('$A$1:$J$56' if index==0 else '$A$1:$B$9')
   for key,value in [('_xlnm.Print_Area',area),('_xlnm.Print_Titles',"'"+name+"'!$1:$1")]:
    assert not any(n.get('name')==key and n.get('localSheetId')==str(index) for n in names)
    E.SubElement(names,Q+'definedName',{'name':key,'localSheetId':str(index)}).text=value
  changed['xl/workbook.xml']=E.tostring(workbook,encoding='utf-8')
  with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as b:
   for info in a.infolist():b.writestr(info,changed.get(info.filename,a.read(info.filename)))
 # Allow exact narrowly declared print nodes only; native semantics/styles unchanged.
 def strip(raw,part):
  root=E.fromstring(raw)
  if part.startswith('xl/worksheets/'):
   prop=root.find('s:sheetPr',NS)
   if prop is not None:
    for node in list(prop):
     if node.tag==Q+'pageSetUpPr':prop.remove(node)
   for node in list(root):
    if node.tag==Q+'pageSetup':root.remove(node)
  elif part=='xl/workbook.xml':
   names=root.find('s:definedNames',NS)
   if names is not None:
    for n in list(names):
     if n.get('name') in ['_xlnm.Print_Area','_xlnm.Print_Titles']:names.remove(n)
    if not len(names):root.remove(names)
  return E.tostring(root)
 checks=[]
 with zipfile.ZipFile(source) as a,zipfile.ZipFile(out) as b:
  assert a.namelist()==b.namelist();assert b.testzip() is None
  for part in a.namelist():
   if part in changed:assert strip(a.read(part),part)==strip(b.read(part),part),part
   else:assert a.read(part)==b.read(part),part
   checks.append({'part':part,'nonprint_preserved':True})
 assert sha(source)==pas['source']['sha256']
 (ROOT/'print-overlay-proof.json').write_text(json.dumps({'status':'NATIVE_PRINT_ONLY_PRESERVATION_PASS','source_sha256':sha(source),'candidate_sha256':sha(out),'checks':checks,'styles_xml_exact_bytes':True,'source_unchanged':True},indent=2)+'\n')
 print('NATIVE_PRINT_ONLY_PRESERVATION_PASS',sha(out))
if __name__=='__main__':main()
