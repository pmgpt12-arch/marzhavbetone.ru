from pathlib import Path
import hashlib,json,re,subprocess,time,sys
import fitz,openpyxl
ROOT=Path(__file__).resolve().parent
CAND=ROOT/'63-reestr-zatrat-po-obektu-Business_Print_candidate.xlsx'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s):return re.sub(r'\s+','',str(s))
def main():
 pas=json.loads((ROOT/'passport.json').read_text());source=ROOT.parent/pas['source']['path']
 before={str(p):sha(p) for p in [source,CAND]};out=ROOT/'pdf-output';out.mkdir(exist_ok=True)
 cmd=['soffice',f'-env:UserInstallation={(ROOT/"pdf-profile").as_uri()}','--headless','--convert-to','pdf','--outdir',str(out),str(CAND)]
 if sys.argv[1:]==['--verify-existing']:
  log=json.loads((ROOT/'pdf-command.json').read_text())
 else:
  t=time.monotonic();log={'command':cmd,'timeout':45}
  try:
   r=subprocess.run(cmd,capture_output=True,text=True,timeout=45);log.update(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
  except Exception as e:log.update(status='STOP_NO_RETRY',error=repr(e))
  log['duration_seconds']=time.monotonic()-t;(ROOT/'pdf-command.json').write_text(json.dumps(log,indent=2)+'\n')
 assert log.get('returncode')==0,'PDF_RUNTIME_STOP'
 pdf=out/(CAND.stem+'.pdf');doc=fitz.open(pdf);text='\n'.join(page.get_text() for page in doc)
 (ROOT/'pdf-text.txt').write_text(text)
 # Mixed fallback fonts can change PyMuPDF span reading order; independent
 # Poppler layout extraction reconstructs the visible C54 colon correctly.
 poppler=subprocess.run(['pdftotext','-layout',str(pdf),'-'],capture_output=True,text=True,timeout=10)
 assert poppler.returncode==0
 (ROOT/'pdf-text-poppler.txt').write_text(poppler.stdout)
 textnorm=norm(poppler.stdout);w=openpyxl.load_workbook(source)
 coverage=[{'sheet':s.title,'cell':c.coordinate,'text':str(c.value),'found':norm(c.value) in textnorm or norm(c.value) in norm(text),
   'exact_contiguous_text_engines':[name for name,body in [('Poppler-layout',textnorm),('PyMuPDF',norm(text))] if norm(c.value) in body]}
   for s in w for row in s for c in row if c.value is not None and c.data_type!='f']
 spans=[{'page':page.number+1,'text':span['text'],'font_size_points':span['size'],'bbox':span['bbox']}
    for page in doc for block in page.get_text('dict')['blocks'] if block['type']==0 for line in block['lines'] for span in line['spans'] if span['text'].strip()]
 sizes=[s['font_size_points'] for s in spans];clips=[]
 for page in doc:
  for span in [s for s in spans if s['page']==page.number+1]:
   x0,y0,x1,y1=span['bbox']
   if x0<0 or y0<0 or x1>page.rect.width+1 or y1>page.rect.height+1:clips.append(span)
  pix=page.get_pixmap(matrix=fitz.Matrix(min(2,1800/page.rect.width),min(2,1800/page.rect.width)),alpha=False);pix.save(ROOT/f'page-{page.number+1}.png')
 preserved=[{'path':p,'before':h,'after':sha(Path(p)),'unchanged':h==sha(Path(p))} for p,h in before.items()]
 report={'status':'TEXT_READABILITY_GEOMETRY_PASS' if all(c['found'] for c in coverage) and min(sizes)>=8 and not clips and all(x['unchanged'] for x in preserved) else 'STOP_PRINT_QA_FAILURE',
  'source_sha256':sha(source),'candidate_sha256':sha(CAND),'pdf_sha256':sha(pdf),'literal_cells_checked':len(coverage),'missing_literals':[c for c in coverage if not c['found']],
  'pages':len(doc),'page_dimensions_points':[[p.rect.width,p.rect.height] for p in doc],'minimum_font_size_points':min(sizes),'text_bbox_outside_pages':clips,'preservation':preserved,
  'all_pages_png':[f'page-{i+1}.png' for i in range(len(doc))],'visual_inspection':'PENDING','model_calls':0,'no_paid_api':True,
  'text_extractor':'Dual exact whole-cell extraction: PyMuPDF OR Poppler pdftotext -layout; mixed-font C54 colon and interleaved-label instructions classified TEXT_EXTRACTOR_READING_ORDER, no rerender',
  'claims_excluded':['native Microsoft Excel approval','legal/currentness','SaleReady']}
 (ROOT/'text-coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'pdf-spans.json').write_text(json.dumps(spans,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'print-checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
