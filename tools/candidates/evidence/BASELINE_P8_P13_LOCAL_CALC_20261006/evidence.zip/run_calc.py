from pathlib import Path
from decimal import Decimal as D
import json,hashlib,subprocess,time,concurrent.futures,openpyxl
ROOT=Path(__file__).resolve().parent; SRC=ROOT.parent/'local-baseline-preflight'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str))
manifest=json.loads((SRC/'input-manifest.json').read_text()); inputs=[i for i in manifest if i['local_path'].endswith('.xlsx')]
for i in inputs:assert sha(Path(i['local_path']))==i['sha256']
version=subprocess.run(['soffice','--version'],capture_output=True,text=True,timeout=10).stdout.strip()
passport={'execution_pattern':'iterative','feedback_loop_required':True,'checkpoint_policy':'verified_only','source_commit':'264d75a06d59de82602dc1bcef347913c44cc648','inputs':inputs,'api_spend_usd':0,'runtime':version,'server_runtime':'LibreOffice 24.2.7.2; local version differs','duplicate_gate':'Limited local inputs manifest/cell dumps contained no Calc cached value proof. Parent accepted-evidence search pending confirmation; no global absence assertion.','timeout_per_calc_seconds':45,'overall_seconds':180,'scope':'Scenario copies only; original source and formulas untouched. Numeric fixture acceptance only; no visual/legal/currentness/Excel/release acceptance.'}
save(ROOT/'passport.json',passport)
fx={}; exp={}
# A/B differ only advance percentage; all figures fictional rubles in same tax basis.
conditions={5:100000,6:30,7:1,8:'пропорционально из каждой КС',9:0,10:12,11:3,12:1,13:5,14:6,15:100,16:4,17:1,18:80,19:1,20:5000}
w=openpyxl.load_workbook(SRC/'02-kalkulyator-usloviy-avansa.xlsx')
for col in ['B','C']:
 for r,v in conditions.items():w['Условия'][f'{col}{r}']=0 if r==6 and col=='C' else v
 for m in range(1,37):w['График КС'][f'{col}{m+4}']=[10,20,30,40][m-1] if m<=4 else 0
p=ROOT/'fixtures';p.mkdir(exist_ok=True);w.save(p/'p8-four-month.xlsx')
fx['p8']={'description':'fictional contract 100000 rubles, month shares10/20/30/40%, 1-month payment delay/cost lead,80% direct cost,5000 startup,5% retention returned month6; A30% and B0% advance;12% annual guarantee3months','Условия':{'B':conditions,'C':{**conditions,6:0}},'График КС':{'B':[10,20,30,40]+[0]*32,'C':[10,20,30,40]+[0]*32}}
# Independent event ledger: direct cost each performance tranche is paid one month early.
# Tranches whose due date precedes/equal first model month are aggregated into month1.
for col,sn,advpc in [('B','Профиль А',D(30)),('C','Профиль Б',D(0))]:
 adv=D(100000)*advpc/100; commission=adv*D('0.12')*D(3)/12
 billed={m:D(v) for m,v in enumerate([10000,20000,30000,40000],1)}
 costs={m:D(0) for m in range(1,37)}
 for m,v in billed.items():costs[max(1,m-1)]+=v*D('.80')
 costs[1]+=D(5000)+commission
 cash={m:D(0) for m in range(1,37)};cash[1]+=adv; cash[6]+=D(5000)
 for m,v in billed.items():cash[m+1]+=v*(1-advpc/100-D('.05'))
 cumulative=D(0);vals={};balances=[]
 for m in range(1,37):
  r=m+4;b=billed.get(m,D(0));repay=b*advpc/100;retain=b*D('.05');due=b-repay-retain;ks=(billed.get(m-1,D(0))*(1-advpc/100-D('.05'))) if m>1 else D(0)
  delta=cash[m]-costs[m];cumulative+=delta;balances.append(cumulative)
  for c,v in {'B':b,'F':repay,'G':retain,'H':due,'I':adv if m==1 else 0,'J':ks,'K':5000 if m==6 else 0,'L':costs[m],'M':delta,'N':cumulative}.items():vals[f'{c}{r}']=v
 totals={'B42':100000,'F42':adv,'G42':5000,'H42':D(100000)-adv-5000,'I42':adv,'J42':D(100000)-adv-5000,'K42':5000,'L42':sum(costs.values()),'M42':cumulative,'N42':cumulative};vals.update(totals);exp[sn]=vals
 exp.setdefault('Условия',{}).update({f'{col}23':adv,f'{col}24':commission,f'{col}25':1})
 negatives=[i+1 for i,v in enumerate(balances) if v<0];lowest=min(balances)
 summary={5:adv,6:commission,7:max(0,-lowest),8:balances.index(lowest)+1 if lowest<0 else 'минуса нет',9:min(negatives) if negatives else 'минуса нет',10:len(negatives),11:adv,12:0,13:0,14:sum(costs.values()),15:cumulative}
 exp.setdefault('Сравнение',{}).update({f'{col}{r}':v for r,v in summary.items()})
for r in [5,6,7,11,12,13,14,15]: exp['Сравнение'][f'D{r}']=D(exp['Сравнение'][f'C{r}'])-D(exp['Сравнение'][f'B{r}'])
for name,profit in [('p13-positive',60000),('p13-zero-profit',0)]:
 w=openpyxl.load_workbook(SRC/'63-reestr-zatrat-po-obektu.xlsx');s=w['Реестр затрат']
 for r,v in [(2,10000),(3,20000),(4,15000)]:
  s[f'H{r}']=v;s[f'D{r}']='нет';s[f'F{r}']='в договоре не распределено';s[f'G{r}']='Условный пункт тестового договора';s[f'I{r}']='в запросе'
 s['H55']=profit;w.save(p/f'{name}.xlsx')
 fx[name]={'H2':10000,'H3':20000,'H4':15000,'H55':profit,'fictional':True};exp[name]={'H54':45000,'H56':D('.75') if profit else ''}
save(ROOT/'fixtures.json',fx);save(ROOT/'expected.json',exp)
start=time.monotonic()
def calc(lane,files):
 out=ROOT/(lane+'-output');out.mkdir(exist_ok=True)
 command=['soffice',f'-env:UserInstallation={(ROOT/(lane+"-profile")).as_uri()}','--headless','--convert-to','xlsx:Calc MS Excel 2007 XML','--outdir',str(out),*[str(p/f) for f in files]]
 result={'command':command,'started_monotonic':time.monotonic()}
 try:
  r=subprocess.run(command,capture_output=True,text=True,timeout=45);result.update(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,status='PROCESS_EXITED')
 except Exception as e:result.update(status='PROCESS_FAILURE_STOP_NO_RETRY',error=repr(e))
 result['duration_seconds']=time.monotonic()-result['started_monotonic'];save(ROOT/(lane+'-command.json'),result);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(lambda args:calc(*args),[('p8',['p8-four-month.xlsx']),('p13',['p13-positive.xlsx','p13-zero-profit.xlsx'])]))
actual={};checks=[]
def check(lane,sheet,cell,expected,got):
 passed=(got in [None,''] if expected=='' else got==expected if isinstance(expected,str) else isinstance(got,(int,float)) and abs(D(str(got))-D(str(expected)))<D('.0000001'))
 checks.append({'lane':lane,'sheet':sheet,'cell':cell,'expected':str(expected) if isinstance(expected,D) else expected,'actual':got,'passed':passed})
if all(r.get('returncode')==0 for r in results):
 w=openpyxl.load_workbook(ROOT/'p8-output/p8-four-month.xlsx',data_only=True)
 for sn,vals in exp.items():
  if sn.startswith('p13'):continue
  actual[sn]={c:w[sn][c].value for c in vals}
  for c,e in vals.items():check('p8',sn,c,e,w[sn][c].value)
 for name in ['p13-positive','p13-zero-profit']:
  w=openpyxl.load_workbook(ROOT/'p13-output'/f'{name}.xlsx',data_only=True);s=w['Реестр затрат'];actual[name]={c:s[c].value for c in exp[name]}
  for c,e in exp[name].items():check(name,s.title,c,e,s[c].value)
save(ROOT/'actual.json',actual);save(ROOT/'checks.json',checks)
after=[{'path':i['local_path'],'before':i['sha256'],'after':sha(Path(i['local_path'])),'unchanged':sha(Path(i['local_path']))==i['sha256']} for i in inputs]
save(ROOT/'source-preservation.json',after)
failed=[c for c in checks if not c['passed']];status='NUMERIC_FIXTURE_PASS' if checks and not failed and all(i['unchanged'] for i in after) else 'FAILURE_STOP_FOR_PARENT_DECISION'
receipt={'status':status,'checks':len(checks),'failed':failed,'commands':results,'source_preservation':after,'duration_seconds':time.monotonic()-start,'api_usd':0,'claims_excluded':['Full visual PASS','Legal/currentness/human review','Microsoft Excel compatibility PASS','SaleReady','Any product source edit']};save(ROOT/'receipt.json',receipt)
print(json.dumps({'status':status,'checks':len(checks),'failed':failed,'duration':receipt['duration_seconds']},ensure_ascii=False))
