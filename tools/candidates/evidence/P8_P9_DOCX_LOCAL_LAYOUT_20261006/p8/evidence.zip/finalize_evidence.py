import hashlib,json,pathlib,re,os
import fitz
from PIL import Image
ROOT=pathlib.Path(__file__).parents[1]
def norm(t):return re.sub(r'\s+','',t).replace('\u00ad','')
for sku in ('p8','p9'):
    root=ROOT/sku;doc=fitz.open(root/'render.pdf');pages=[p.get_text() for p in doc];natural='\n'.join(pages)
    (root/'pdf-natural-text.txt').write_text(natural)
    units=json.loads((root/'source-text.json').read_text());checks=[]
    for u in units:
        item=dict(u,present=norm(u['text']) in norm(natural),method='PyMuPDF natural block order; whitespace/soft-hyphen normalization')
        if sku=='p8' and u['paragraph_index']==48:
            prefix='Срок работ считать с даты поступления';suffix='аванса'
            assert norm(prefix+suffix)==norm(u['text'])
            assert norm(prefix) in norm(pages[2]);assert norm(suffix) in norm(pages[3])
            assert doc[2].search_for('Срок работ считать с') and doc[3].search_for('аванса')
            item.update(present=True,method='Exact same source paragraph split across page3/page4; visible first table column; repeated heading/other cells interrupt extraction order',fragments=[{'page':3,'quote':prefix},{'page':4,'quote':suffix}],visual_confirmation=True)
        checks.append(item)
    assert all(c['present'] for c in checks)
    result={'total':len(checks),'matched':len(checks),'units':checks,'source_bound':True,'initial_layout_extraction_retained':'text-coverage.json','classification':'PDF_READING_ORDER_TABLE_COLUMN_INTERLEAVING' if sku=='p8' else None,'rule':'A raw sequential substring mismatch is not text loss; inspect natural PDF block order and exact source-bound page fragments before classification','negative_gate':'Never accept a missing fragment; no tokens or clauses removed from required coverage'}
    (root/'text-coverage-final.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    observation={'status':'LOCAL_LAYOUT_EVIDENCE_COMPLETE_INDEPENDENT_REVIEW_PENDING','pages_inspected':list(range(1,len(pages)+1)),'no_observed_clipping_or_overlap':True,'observations':(['Page2 has only one continued bullet. Table row splits page3/page4 leaving isolated word аванса; complete but less convenient. Repeated header visible page4. Page6 mostly blank after three paragraphs. All seven pages inspected.'] if sku=='p8' else ['All six pages inspected, with page5 using recovered PNG from unchanged PDF. Long tokens wrap on pages4/5 but remain visible. Warning boxes, template signature/application area and instructions readable. Original failed page5 PNG retained.']),'runtime_scope':'LibreOfficeDev26.8 local render only; Microsoft Word/server24.2/current legal semantics not validated','official_currentness':'NOT_VERIFIED','human_legal':'NOT_PERFORMED','word_compatibility':'NOT_VERIFIED','sale_ready':False}
    (root/'observations.json').write_text(json.dumps(observation,ensure_ascii=False,indent=2)+'\n')
    valid=[]
    for i in range(1,len(pages)+1):
        png=root/(f'page-{i}-recovered.png' if sku=='p9' and i==5 else f'page-{i}.png');b=png.read_bytes();assert b.endswith(b'\0\0\0\0IEND\xaeB`\x82')
        with Image.open(png) as im:im.verify()
        with Image.open(png) as im:im.load()
        valid.append({'path':png.name,'sha256':hashlib.sha256(b).hexdigest(),'size':len(b),'valid':True})
    receipt=json.loads((root/'receipt.json').read_text());src=pathlib.Path(receipt['source']['local_path']);assert hashlib.sha256(src.read_bytes()).hexdigest()==receipt['source']['sha256']
    final={'status':observation['status'],'source_sha_after':hashlib.sha256(src.read_bytes()).hexdigest(),'coverage':{'total':len(checks),'matched':len(checks)},'png_final_readback':valid,'original_receipt_preserved':'receipt.json','no_writer_retry':True,'paid_api_calls':0}
    (root/'final-receipt.json').write_text(json.dumps(final,indent=2)+'\n')
    files=sorted(p for p in root.iterdir() if p.is_file() and p.name not in ('SHA256SUMS','execution.lock'))
    (root/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in files))
    for p in files+[root/'SHA256SUMS']:
        with p.open('rb') as f:os.fsync(f.fileno())
    print(sku,len(pages),'pages',len(checks),'units',len(files),'artifacts')
