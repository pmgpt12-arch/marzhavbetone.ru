import concurrent.futures,datetime,hashlib,json,os,pathlib,re,subprocess,time,zipfile
from lxml import etree
from PIL import Image
import fitz

ROOT=pathlib.Path('/workspace/scratch/f25d74acc3f7/daywork-next-queue-20261006')
def write(path,obj): path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def norm(s): return re.sub(r'\s+','',s).replace('\u00ad','')
def run(task):
    out=pathlib.Path(task['scope']['write_only_output']);out.mkdir(exist_ok=True)
    lock=out/'execution.lock';fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY);os.write(fd,str(os.getpid()).encode());os.close(fd)
    src=pathlib.Path(task['scope']['read_only_input']);data=src.read_bytes();inp=task['required_inputs'][0]
    assert hashlib.sha256(data).hexdigest()==inp['sha256']; assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==inp['git_blob']
    for dep in task['dependencies']: assert hashlib.sha256(pathlib.Path(dep['path']).read_bytes()).hexdigest()==dep['sha256']
    write(out/'passport.json',task)
    receipt={'task_id':task['task_id'],'pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':inp,'commands':[],'status':'RUNNING','api_calls':0}
    def command(argv):
        started=time.monotonic(); p=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try: stdout,stderr=p.communicate(timeout=45)
        except subprocess.TimeoutExpired:
            p.kill();stdout,stderr=p.communicate();receipt['commands'].append({'argv':argv,'pid':p.pid,'returncode':p.returncode,'stdout':stdout,'stderr':stderr,'timeout':True});raise
        receipt['commands'].append({'argv':argv,'pid':p.pid,'returncode':p.returncode,'stdout':stdout,'stderr':stderr,'elapsed_seconds':time.monotonic()-started});write(out/'receipt.json',receipt)
        assert p.returncode==0,(argv,p.returncode,stderr); return stdout
    try:
        receipt['runtime_version']=command(['soffice','--version']).strip()
        command(['soffice','-env:UserInstallation='+pathlib.Path(task['executor']['profile']).as_uri(),'--headless','--convert-to','pdf','--outdir',str(out),str(src)])
        pdf=out/(src.stem+'.pdf');assert pdf.stat().st_size>0;pdf.rename(out/'render.pdf');pdf=out/'render.pdf'
        command(['pdftotext','-layout',str(pdf),str(out/'pdf-text.txt')])
        command(['pdftoppm','-scale-to','1600','-png',str(pdf),str(out/'page')])
        units=[];ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
        with zipfile.ZipFile(src) as z:
            for name in z.namelist():
                if name=='word/document.xml' or re.fullmatch(r'word/(header|footer)\d+\.xml',name):
                    tree=etree.fromstring(z.read(name))
                    for i,p in enumerate(tree.xpath('//w:p',namespaces=ns)):
                        text=''.join(p.xpath('.//w:t/text()',namespaces=ns))
                        if text.strip(): units.append({'part':name,'paragraph_index':i,'xpath':p.getroottree().getpath(p),'text':text})
        write(out/'source-text.json',units)
        plain=(out/'pdf-text.txt').read_text();coverage=[dict(u,present=norm(u['text']) in norm(plain)) for u in units];write(out/'text-coverage.json',{'units':coverage,'matched':sum(u['present'] for u in coverage),'total':len(coverage),'normalization':'Whitespace and soft hyphen removed only'})
        doc=fitz.open(pdf);pngs=sorted(out.glob('page-*.png'));assert len(pngs)==len(doc)
        receipt['pages']=len(doc);receipt['png_validation']=[]
        for png in pngs:
            with Image.open(png) as im: im.verify()
            with Image.open(png) as im: im.load();receipt['png_validation'].append({'name':png.name,'size':im.size,'valid':True})
        assert all(u['present'] for u in coverage),'TEXT_COVERAGE_MISMATCH'
        assert hashlib.sha256(src.read_bytes()).hexdigest()==inp['sha256']
        receipt['source_sha_after']=hashlib.sha256(src.read_bytes()).hexdigest();receipt['text_units']=len(units);receipt['status']='MECHANICAL_PASS_VISUAL_REVIEW_PENDING'
    except Exception as exc: receipt['status']='STOP';receipt['error']=repr(exc)
    receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();write(out/'receipt.json',receipt);return {'task':task['task_id'],'status':receipt['status'],'error':receipt.get('error'),'pages':receipt.get('pages'),'units':receipt.get('text_units')}

if __name__=='__main__':
    tasks=json.loads((ROOT/'queue.json').read_text())['tasks'][:2]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: print(json.dumps(list(pool.map(run,tasks))))
