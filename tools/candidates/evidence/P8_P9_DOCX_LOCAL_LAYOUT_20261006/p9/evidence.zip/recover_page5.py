import datetime,hashlib,json,os,pathlib,subprocess,time
from PIL import Image
p=pathlib.Path(__file__).parent
pdf=p/'render.pdf';failed=p/'page-5.png';before=hashlib.sha256(pdf.read_bytes()).hexdigest()
argv=['pdftoppm','-f','5','-l','5','-singlefile','-scale-to','1600','-png',str(pdf),str(p/'page-5-recovered')]
start=time.monotonic();proc=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
try:stdout,stderr=proc.communicate(timeout=45)
except subprocess.TimeoutExpired:proc.kill();stdout,stderr=proc.communicate();raise
out=p/'page-5-recovered.png';receipt={'authorized_by':'root scoped recovery 2026-10-06','argv':argv,'pid':proc.pid,'returncode':proc.returncode,'stdout':stdout,'stderr':stderr,'elapsed_seconds':time.monotonic()-start,'pdf_sha_before':before,'failed_png_sha256':hashlib.sha256(failed.read_bytes()).hexdigest(),'failed_png_size':failed.stat().st_size,'failure':'OSError Truncated File Read on independent readback after initially valid PIL load; no source or PDF rerender','failure_class':'PRODUCER_WRITE_COMPLETENESS_OR_ARTIFACT_DRIFT','hypothesis':'PNG artifact incomplete on final readback; exact cause not established','rule':'Exit0 and initial load do not close PNG gate: fsync then verify/load/IEND and final manifest/readback before acceptance','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
assert proc.returncode==0
with out.open('rb') as f:os.fsync(f.fileno())
fd=os.open(p,os.O_RDONLY);os.fsync(fd);os.close(fd)
b=out.read_bytes();assert b.endswith(b'\0\0\0\0IEND\xaeB`\x82')
with Image.open(out) as im:im.verify()
with Image.open(out) as im:im.load();receipt['image_size']=im.size
receipt['pdf_sha_after']=hashlib.sha256(pdf.read_bytes()).hexdigest();assert receipt['pdf_sha_after']==before
receipt['recovered_png_sha256']=hashlib.sha256(b).hexdigest();receipt['recovered_png_bytes']=len(b);receipt['status']='RECOVERY_BYTES_VALID_VISUAL_PENDING'
(p/'page5-recovery.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt))
