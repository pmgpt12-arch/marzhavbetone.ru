import pathlib,json,hashlib,subprocess,time,datetime,re,concurrent.futures,zipfile,xml.etree.ElementTree as ET
import fitz
from PIL import Image
R=pathlib.Path('/workspace/scratch/f25d74acc3f7/daywork-next-queue-20261006'); Q=json.loads((R/'queue.json').read_text()); NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s):return re.sub(r'\s+','',s).replace('\u00ad','')
def run(t):
 O=pathlib.Path(t['scope']['write_only_output']); I=t['required_inputs'][0]; p=pathlib.Path(I['local_path']); rec={'task_id':t['task_id'],'source':I,'source_before':sha(p),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[],'status':'STARTED','source_writes':0,'api_usd':0}
 def save():(O/'receipt.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n')
 def cmd(argv):
  start=time.monotonic()
  try:
   c=subprocess.run(argv,text=True,capture_output=True,timeout=45); v={'argv':argv,'exit_code':c.returncode,'stdout':c.stdout,'stderr':c.stderr,'seconds':time.monotonic()-start};rec['commands'].append(v);save();assert c.returncode==0,v
  except subprocess.TimeoutExpired as e:
   rec['commands'].append({'argv':argv,'status':'TIMEOUT_DO_NOT_RETRY','seconds':time.monotonic()-start});save();raise
  return c.stdout
 try:
  assert rec['source_before']==I['sha256']; units=[]
  with zipfile.ZipFile(p) as z:
   for part in sorted(z.namelist()):
    if part=='word/document.xml' or re.fullmatch(r'word/(header|footer)\d+\.xml',part):
     tree=ET.fromstring(z.read(part))
     for j,para in enumerate(tree.findall('.//w:p',NS)):
      txt=''.join(x.text or '' for x in para.findall('.//w:t',NS))
      if txt.strip():units.append({'locator':f'{part}/paragraph:{j}','source_text':txt})
  (O/'source-text.json').write_text(json.dumps(units,ensure_ascii=False,indent=2)+'\n');rec['version']=cmd(['soffice','--version']).strip();cmd(['soffice','-env:UserInstallation='+(O/'profile').as_uri(),'--headless','--convert-to','pdf','--outdir',str(O),str(p)]);pdf=O/(p.stem+'.pdf');assert pdf.is_file() and pdf.stat().st_size>0;cmd(['pdftotext','-layout',str(pdf),str(O/'pdf-text.txt')]);cmd(['pdftoppm','-scale-to','1600','-png',str(pdf),str(O/'page')]);text=(O/'pdf-text.txt').read_text();f=fitz.open(pdf);pages=len(f);assert pages>0
  pngs=sorted(O.glob('page-*.png'));assert len(pngs)==pages; imgs=[]
  for g in pngs:
   with Image.open(g) as im:im.verify()
   with Image.open(g) as im:im.load();imgs.append({'path':g.name,'size':list(im.size),'format':im.format,'sha256':sha(g)})
  for u in units:u['present_normalized']=norm(u['source_text']) in norm(text)
  unmatched=[u for u in units if not u['present_normalized']]
  coverage={'units_checked':len(units),'unmatched_count':len(unmatched),'unmatched':unmatched,'records':units,'normalization':'Whitespace and soft-hyphen removal only; no semantic substitution','pages':pages};(O/'text-coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n');rec.update({'pages':pages,'png_validation':imgs,'units_checked':len(units),'unmatched_count':len(unmatched),'source_after':sha(p),'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'RENDER_AND_TEXT_CHECK_PASS_PENDING_VISUAL_REVIEW' if not unmatched else 'TEXT_COVERAGE_MISMATCH_STOP'});assert rec['source_after']==rec['source_before'];save();print(t['task_id'],rec['status'],pages,len(units),len(unmatched),flush=True)
 except Exception as e:rec['status']='STOP_PRESERVED_NO_RETRY';rec['error']=repr(e);rec['source_after']=sha(p);save();print(t['task_id'],rec['status'],repr(e),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,[t for t in Q['tasks'] if t['task_id'].startswith(('p11-','p13-'))]))
