import pathlib,subprocess,time,json,hashlib
from PIL import Image
R=pathlib.Path('/workspace/scratch/f25d74acc3f7/baseline-docx-local'); p=R/'p9-original/page-3.png'; rec={'failed_path':str(p),'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'signature_hex':p.read_bytes()[:8].hex(),'original_command':json.loads((R/'run.json').read_text())['commands'][6]}
try:Image.open(p).verify();rec['verify']='PASS'
except Exception as e:rec['verify']=str(e)
# Original wrapper command returned rc0; other 6 PNGs complete, only page3 truncated at 192KiB. No causal claim beyond artifact truncation.
rec['cause']='PNG stream truncated at 196608 bytes. Original pdftoppm returned exit0; cause of incomplete output not established.'
a=['pdftoppm','-f','3','-l','3','-singlefile','-scale-to','1600','-png',str(R/'p9-original/01-slovar-poley-bankrotstvo.pdf'),str(R/'p9-original/page-3-recovered')]; t=time.monotonic();z=subprocess.run(a,text=True,capture_output=True,timeout=20);rec['recovery_command']={'argv':a,'rc':z.returncode,'stdout':z.stdout,'stderr':z.stderr,'elapsed_s':time.monotonic()-t};q=R/'p9-original/page-3-recovered.png'
try:Image.open(q).verify();rec['recovery_verify']='PASS';rec['recovery_sha256']=hashlib.sha256(q.read_bytes()).hexdigest()
except Exception as e:rec['recovery_verify']=str(e)
(R/'page3-recovery.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2));print(json.dumps(rec))
