import pathlib,json,hashlib,subprocess,time,datetime
from docx import Document
R=pathlib.Path('/workspace/scratch/f25d74acc3f7/baseline-docx-local'); manifest=json.loads(pathlib.Path('/workspace/scratch/f25d74acc3f7/local-baseline-preflight/input-manifest.json').read_text()); rec={'source_commit':'264d75a06d59de82602dc1bcef347913c44cc648','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'version':subprocess.check_output(['soffice','--version'],text=True).strip(),'inputs':[],'commands':[]}
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cmd(a):
 start=time.monotonic();r=subprocess.run(a,capture_output=True,text=True,timeout=45);rec['commands'].append({'argv':a,'rc':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'elapsed_s':time.monotonic()-start,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}); (R/'run.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2));assert r.returncode==0
jobs=[]
for ix,label in [(0,'p4-original'),(2,'p9-original')]:
 i=manifest[ix];p=pathlib.Path(i['local_path']);assert sh(p)==i['sha256'];rec['inputs'].append(dict(i,sha_before=sh(p)));d=Document(p); lines=[]
 for child in d.element.body:
  texts=[x.text or '' for x in child.iter() if x.tag.endswith('}t')];lines.append(' '.join(texts))
 (R/(label+'-source-text.txt')).write_text('\n'.join(lines));jobs.append((label,p))
# P4 filled copy is deliberately fictional, limited to existing placeholders; no new legal assertions.
p=pathlib.Path(manifest[0]['local_path']);d=Document(p)
replacements={'[На бланке организации]':'УЧЕБНЫЙ ПРИМЕР — ВЫМЫШЛЕННЫЕ ДАННЫЕ','Исх. № _____ от \'___\' ___________ 20___ г.':'Исх. № УЧ-17 от 06 октября 2026 г.','[Наименование заказчика]':'ООО «Учебный заказчик Северный строительный объект»','[ФИО представителя]':'Иванову Ивану Ивановичу (вымышленное лицо)','[Наименование подрядчика]':'ООО «Учебный подрядчик Монтаж строительных конструкций»','[ФИО]':'Иван Иванович (вымышленное лицо)','[номер]':'УЧ-01','[дата]':'06.10.2026','[перечислить]':'монтажные работы на учебном объекте — исполнительные схемы и акты','КС-2 № _____ от _____ (___ листов)':'КС-2 № УЧ-1 от 06.10.2026 (12 листов)','КС-3 № _____ от _____ (___ листов)':'КС-3 № УЧ-1 от 06.10.2026 (2 листа)','Акты скрытых работ (___ актов, ___ листов)':'Акты скрытых работ (8 актов, 24 листа)','Исполнительные схемы (___ листов)':'Исполнительные схемы (16 листов)','Сертификаты и паспорта (___ документов)':'Сертификаты и паспорта (10 документов)'}
for para in d.paragraphs:
 for old,new in replacements.items():
  if old in para.text:
   # original target tokens are contained within runs; retain run formatting.
   for run in para.runs: run.text=run.text.replace(old,new)
filled=R/'p4-fictional-filled.docx';d.save(filled);jobs.append(('p4-filled',filled))
rec['scenario']={'p4':'Fictional party names and document inventory replace placeholders in copy only; existing legal text untouched. Signature line intentionally remains blank.','p9':'Glossary is guidance, not a submission form. All literal token definitions retained; replacing them would defeat the instructional purpose.'}
for label,source in jobs:
 out=R/label;out.mkdir(exist_ok=True);profile=R/(label+'-profile');cmd(['soffice','-env:UserInstallation='+profile.as_uri(),'--headless','--convert-to','pdf','--outdir',str(out),str(source)]);pdf=out/(source.stem+'.pdf');assert pdf.exists();cmd(['pdftotext','-layout',str(pdf),str(out/'pdf-text.txt')]);cmd(['pdftoppm','-scale-to','1600','-png',str(pdf),str(out/'page')]);cmd(['pdfinfo',str(pdf)])
for i in rec['inputs']:i['sha_after']=sh(pathlib.Path(i['local_path']));assert i['sha_after']==i['sha_before']
rec['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();rec['artifacts']=[{'path':str(p),'sha256':sh(p),'size':p.stat().st_size} for p in sorted(R.rglob('*')) if p.is_file() and '-profile' not in str(p) and p.name!='run.json'];(R/'run.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2));print([(label,len(list((R/label).glob('page-*.png')))) for label,_ in jobs])
