import pathlib,json,re,hashlib,datetime,fitz
from docx import Document
R=pathlib.Path('/workspace/scratch/f25d74acc3f7/baseline-docx-local'); rec=json.loads((R/'run.json').read_text()); checks=[]
def norm(t):return re.sub(r'\s+','',t).replace('\u00ad','')
for label,p in [('p4-original',pathlib.Path(rec['inputs'][0]['local_path'])),('p9-original',pathlib.Path(rec['inputs'][1]['local_path'])),('p4-filled',R/'p4-fictional-filled.docx')]:
 d=Document(p); pdf=next((R/label).glob('*.pdf'));f=fitz.open(pdf);text='\n'.join(q.get_text() for q in f) if label=='p9-original' else (R/label/'pdf-text.txt').read_text(); units=[]
 for j,p in enumerate(d.paragraphs):
  if p.text.strip():units.append((f'paragraph:{j}',p.text))
 for ti,t in enumerate(d.tables):
  for ri,r in enumerate(t.rows):
   for ci,c in enumerate(r.cells):
    if c.text.strip():units.append((f'table:{ti}/row:{ri}/cell:{ci}',c.text))
 records=[{'locator':loc,'source_text':t,'present_in_pdf_normalized':norm(t) in norm(text)} for loc,t in units]; checks.append({'label':label,'pages':len(f),'units_checked':len(records),'unmatched':[x for x in records if not x['present_in_pdf_normalized']],'records':records}); (R/(label+'-natural-pdf-text.txt')).write_text(text)
(R/'text-coverage.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2));print([(i['label'],i['units_checked'],len(i['unmatched'])) for i in checks])
observations={'status':'COMPLETE_LOCAL_VISUAL_OBSERVATION_WITH_FINDINGS','runtime_limitation':'LibreOfficeDev26.8alpha0 local renderer differs from ai-workstation LibreOffice24.2; not Microsoft Word acceptance.','source_commit':rec['source_commit'],'source_integrity':[{'path':i['local_path'],'sha256':i['sha_before'],'before_equals_after':i['sha_before']==i['sha_after']} for i in rec['inputs']], 'inspected_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pages_visually_inspected':{'p4-original':[1,2],'p4-filled':[1,2],'p9-original':[1,2,3,4,5,6,7]},'findings':[{'id':'P4-V01','scope':'Original pages1–2; filled pages1–2','severity':'MINOR_READABILITY','finding':'Document inventory wraps across page boundary (one item on next page original, two in filled scenario). All text remains visible; no overlap/truncation. Large heading and blank paragraphs produce 2-page letter. Not a missing-content defect.'},{'id':'P9-V01','scope':'Page2','severity':'PAGINATION_OBSERVATION','finding':'Page2 contains only the final two lines of source-information bullet, then large empty remainder before Parties table begins page3. No content lost; no claimed functional block.'},{'id':'P9-V02','scope':'Pages3–6 first/second table columns','severity':'COPY_READABILITY_RISK','finding':'Long {{FIELD_NAME}} tokens wrap inside words; all characters retained in normalized PDF text. Exact examples {{НАИМЕНОВАНИЕ_КРЕДИТОРА}} and {{ДАТА_ОПРЕДЕЛЕНИЯ}} wrap across lines, latter closing braces alone. Manual copying/transcription may be harder, but no clipping/overlap detected.'},{'id':'ART-V01','scope':'Initial p9 page3 PNG','severity':'RECOVERED_ARTIFACT_FAILURE','finding':'Initial PNG truncated at 196608 bytes despite pdftoppm rc0. Original failed file preserved. Parent-authorized single extraction from unchanged PDF using20sec timeout passed PIL.verify and visual review; no second LibreOffice conversion.'}],'text_coverage_summary':[{'label':x['label'],'units':x['units_checked'],'unmatched_count':len(x['unmatched'])} for x in checks], 'duplicate_gate':{'search':'rg exact two SHA strings in local mb001-daywork .md/.json','result':'No matches in limited local checkout; not global absence of accepted proofs.'},'not_verified':['legal source currentness','normative/legal correctness','human legal acceptance','Microsoft Word rendering','full repackaged product readiness','SaleReady'],'api_spend_usd':0,'source_edits':False,'git_writes':False}
(R/'observations.json').write_text(json.dumps(observations,ensure_ascii=False,indent=2))
md='''# Cached baseline P4/P9: local DOCX visual observations

Exact input bytes from commit `264d75a06d59de82602dc1bcef347913c44cc648` were read, rendered, compared with PDF text, and visually inspected on every page. P4 original: 2 pages; fictional filled-copy scenario: 2 pages; P9 glossary: 7 pages. Original SHA-256 before/after is identical for both files. No product edits, server actions, Git mutations, or API calls.

LibreOfficeDev 26.8.0.0.alpha0 local runtime differs from the server's 24.2 and Microsoft Word. This report describes this render only.

P4: no clipped or overlapping text. Inventory breaks across the page boundary in both blank and filled scenarios; the final page has substantial spare space. Signature blanks are intentional. Filled copy is explicitly marked fictional and exercises longer party names and a document list; repeated generic source placeholders receive generic values and are not a legal-use example.

P9: all seven pages inspected. Page2 carries only two lines before the Parties table starts on page3. Long field tokens wrap inside words in tables; text remains visible, but copying tokens manually is less convenient. Continuation table header on page4 is visible. Warning box, procedures, tables, cross-kit mapping, and final workflow remain readable with no observed overlap or clipped cells. Literal tokens retained because this file explains token definitions rather than being a submission form.

Initial P9 page3 PNG was truncated despite rc0. Failed PNG retained. One specifically authorized extraction of page3 from the unchanged PDF passed PIL.verify and was inspected. No original DOCX rerender occurred.

Complete per-unit source/PDF matching is in `text-coverage.json`, each source paragraph or table cell has a locator; command outputs, profiles, timing and output hashes are in `run.json`. Observations and explicit acceptance limits are in `observations.json`.

Legal/currentness/human acceptance, Microsoft Word compatibility and SaleReady remain NOT_VERIFIED. Pagination and token wrapping are observations; no automatic release approval follows from this result.
'''
(R/'REPORT.md').write_text(md)
# Final artifact hashes exclude ephemeral profile files and hash manifest itself.
files=[p for p in sorted(R.rglob('*')) if p.is_file() and '-profile' not in str(p) and p.name!='SHA256SUMS'];(R/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(R))+'\n' for p in files))
