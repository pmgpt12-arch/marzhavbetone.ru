from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,time
import openpyxl
ROOT=Path(__file__).resolve().parent
CAND=ROOT/'63-reestr-zatrat-po-obektu-Business_Design_candidate.xlsx'
REF=ROOT.parent/'excel-design-reference-20261006/P1_04_Uchet_Business_Design_v1.xlsx'
SOURCE=ROOT.parent/'local-baseline-preflight/63-reestr-zatrat-po-obektu.xlsx'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,x):(ROOT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
before={str(p):sha(p) for p in [SOURCE,CAND,REF]}
fixtures=ROOT/'fixtures';fixtures.mkdir(exist_ok=True)
for name,profit in [('p13-positive',60000),('p13-zero-profit',0)]:
 w=openpyxl.load_workbook(CAND);s=w['Реестр затрат']
 for r,v in [(2,10000),(3,20000),(4,15000)]:
  for col,value in [('H',v),('D','нет'),('F','в договоре не распределено'),('G','Условный пункт тестового договора'),('I','в запросе')]:s[f'{col}{r}']=value
 s['H55']=profit;w.save(fixtures/f'{name}.xlsx')
version=subprocess.run(['soffice','--version'],capture_output=True,text=True,timeout=10).stdout.strip()
def run(lane,fmt,files):
 out=ROOT/(lane+'-output');out.mkdir(exist_ok=True)
 cmd=['soffice',f'-env:UserInstallation={(ROOT/(lane+"-profile")).as_uri()}','--headless','--convert-to',fmt,'--outdir',str(out),*[str(f) for f in files]]
 start=time.monotonic();r={'command':cmd,'timeout':45,'isolated_profile':str(ROOT/(lane+'-profile'))}
 try:
  proc=subprocess.run(cmd,capture_output=True,text=True,timeout=45);r.update(returncode=proc.returncode,stdout=proc.stdout,stderr=proc.stderr)
 except Exception as exc:r.update(status='STOP_NO_RETRY',error=repr(exc))
 r['duration_seconds']=time.monotonic()-start;dump(lane+'-command.json',r);return lane,r
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 result=dict(pool.map(lambda a:run(*a),[('calc','xlsx:Calc MS Excel 2007 XML',[fixtures/'p13-positive.xlsx',fixtures/'p13-zero-profit.xlsx']),('pdf','pdf',[CAND,REF])]))
checks=[]
if result['calc'].get('returncode')==0:
 for name,ratio in [('p13-positive',0.75),('p13-zero-profit','')]:
  p=ROOT/'calc-output'/f'{name}.xlsx';f=openpyxl.load_workbook(p,data_only=False);v=openpyxl.load_workbook(p,data_only=True)
  for cell,expected in [('H54',45000),('H56',ratio)]:
   actual=v['Реестр затрат'][cell].value;passed=actual==expected if expected!='' else actual in [None,'']
   checks.append({'fixture':name,'cell':cell,'expected':expected,'actual':actual,'passed':passed})
  for cell,expected in [('H54','=SUM(H2:H52)'),('H56','=IF(H55=0,"",H54/H55)')]:
   assert f['Реестр затрат'][cell].value==expected
preservation=[{'path':n,'sha256_before':h,'sha256_after':sha(Path(n)),'unchanged':h==sha(Path(n))} for n,h in before.items()]
pdfs=list((ROOT/'pdf-output').glob('*.pdf'))
report={'status':'CALC_FIXTURES_PASS_PDF_CREATED' if len(checks)==4 and all(c['passed'] for c in checks) and all(p['unchanged'] for p in preservation) and len(pdfs)==2 and result['pdf'].get('returncode')==0 else 'STOP_PARTIAL_RESULT',
 'runtime':version,'candidate_sha256':sha(CAND),'checks':checks,'preservation':preservation,'commands':result,'pdfs':[{'name':p.name,'sha256':sha(p),'bytes':p.stat().st_size} for p in pdfs],
 'claims_excluded':['native Excel rendering acceptance','full print acceptance','legal/currentness','SaleReady'],'model_calls':0,'cost_usd':0}
dump('candidate-checks.json',report);print(json.dumps(report,ensure_ascii=False))
