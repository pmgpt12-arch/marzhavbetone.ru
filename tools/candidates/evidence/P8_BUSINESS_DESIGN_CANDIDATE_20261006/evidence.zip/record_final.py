import pathlib, json, hashlib, openpyxl, copy
R = pathlib.Path(__file__).resolve().parent
s = openpyxl.load_workbook(R.parent/'local-baseline-preflight/02-kalkulyator-usloviy-avansa.xlsx')
c = openpyxl.load_workbook(R/'02-kalkulyator-usloviy-avansa-Business_Design_candidate.xlsx')
checks = []
for sh in s:
    for row in sh:
        for x in row:
            y = c[sh.title][x.coordinate]
            if sh.title == 'Как читать' or (x.font.color and x.font.color.type == 'rgb' and x.font.color.rgb in ['00C00000', '000000FF', '00008000']):
                checks.append({'sheet': sh.title, 'cell': x.coordinate, 'font_exact': copy.copy(x.font) == copy.copy(y.font), 'value_exact': x.value == y.value})
assert all(v['font_exact'] and v['value_exact'] for v in checks), [v for v in checks if not v['font_exact']]
(R/'legend-status-preservation.json').write_text(json.dumps({'checks': checks, 'count': len(checks), 'passed': True, 'scope': 'All literal color legend cells and semantic red/blue/green native fonts preserved; status/crossreference/value text exact', 'comparison': 'StyleProxy copied to actual Font before equality'}, ensure_ascii=False, indent=2)+'\n')
obs = {'status': 'STYLE_ONLY_NUMERIC_CANDIDATE_READY_PRINT_STOP', 'pages_overview_inspected': list(range(1, 32)), 'detail_pages_inspected': [1,25,29], 'native_style_preservation': 'PASS all nonstyle worksheet XML and native print/layout settings exact source', 'numeric': '776 expected checks PASS; all 1178 Calc formulas equal accepted retained Calc output; raw candidate formulas exact source', 'legend': 'Source input blue, reference green, status red and color legend text retained; input fill reference muted yellow-gold', 'findings': [{'id':'P8-PRINT-01','class':'FULL_NATIVE_PRINT_READABILITY_NOT_ACCEPTED','observed_fact':'Native default PDF is 31 pages. Source widths/print settings retained. Wide sheets split horizontally: Условия pages1–4, profiles 8 pages each, comparison 3 pages, guidance 2 pages. Headers/instructions fragmented across pages; unsuitable as compact buyer handout.','attribution':'Not attributed to style overlay: print settings unchanged, no original native PDF baseline rendered in this task.','next_task':'Separate print/layout candidate scope with print fit and content preservation gates'}, {'id':'P8-TEXT-01','class':'PDF_SENTENCE_COVERAGE_UNRESOLVED','observed_fact':'225 static strings checked; 26 normalized sentence containment mismatches. Horizontal pagination/extraction reading order may cause mismatch; native XML exact but full PDF text coverage not accepted.','next_task':'Inspect 26 exact locators in separate print scope; keep gate'}], 'limits':['Full print acceptance STOP','Native Excel owner review pending','Legal/financial/currentness not covered','SaleReady false','Full compact summary not implemented'], 'source_changed':False,'api_usd':0}
(R/'observations.json').write_text(json.dumps(obs,ensure_ascii=False,indent=2)+'\n')
(R/'REPORT.md').write_text('''# P8 approved business style: scoped candidate

Exact source SHA256 079535ecc577dc0a7396cb6d122e5060e6121fa60d9d024763c153fd2bf304ec and approved reference 93252d5711cbbd33e682b3f9400fe6ee9aa9ed02c49cf8302ae89976ffc20d77 remain unchanged. Contract PR491 merged; reference metadata acceptance is separate from target acceptance.

26 semantic roles style 1280 existing cells across 7 sheets. Roles follow actual instructions, formulas and validation. Source color legend remains functional: blue input, green links, red warnings preserved. Graphite headers, muted gold entry fill and light borders use reference components. No new summary/cells/layout/text/formula/protection/validation/number-format/print changes. P13 native ZIP overlay reused with target scope adapters; no new framework.

Raw nonstyle XML/other ZIP parts/1178 formulas and caches are exact source. One 45-second bounded Calc fixture and one bounded PDF export ran concurrently with separate profiles, both exit0. All 776 known four-month numeric checks pass. All 1178 Calc formulas match the accepted same-runtime baseline; 586 raw input formula-string differences are identical Calc sheet-name quote normalization, not candidate regression.

PRINT_STOP: actual native PDF is 31 pages with horizontal splits and fragmented headings/instructions from unchanged print settings. 225 static strings checked; 26 sentence-containment mismatches need a separate print scope. Durable style/numeric candidate evidence only; not a finished printable or Excel-owner-accepted product. No source promotion/legal/currentness/SaleReady/server actions.
''')
files = [p for p in sorted(R.rglob('*')) if p.is_file() and not any(x.endswith('-profile') for x in p.parts) and p.name != 'SHA256SUMS']
(R/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(R))+'\n' for p in files))
print('legend checks',len(checks))
