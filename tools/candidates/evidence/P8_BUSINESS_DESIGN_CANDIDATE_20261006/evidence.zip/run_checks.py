from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,time,openpyxl,datetime
from decimal import Decimal
R=Path(__file__).resolve().parent;SRC=R.parent/'local-baseline-preflight/02-kalkulyator-usloviy-avansa.xlsx';CAND=R/'02-kalkulyator-usloviy-avansa-Business_Design_candidate.xlsx';REF=R.parent/'excel-design-reference-20261006/P1_04_Uchet_Business_Design_v1.xlsx';B=R.parent/'baseline-calc-local'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,x):(R/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
before={str(p):sha(p)for p in [SRC,CAND,REF]};fixturedata=json.loads((B/'fixtures.json').read_text())['p8'];w=openpyxl.load_workbook(CAND);condition=fixturedata['Условия']
for col in ['B','C']:
 for row,value in condition[col].items():w['Условия'][f'{col}{row}']=value
 for m,value in enumerate(fixturedata['График КС'][col],5):w['График КС'][f'{col}{m}']=value
fx=R/'fixtures';fx.mkdir(exist_ok=True);fpath=fx/'p8-four-month.xlsx';w.save(fpath);dump('fixture-definition.json',fixturedata)
version=subprocess.run(['soffice','--version'],text=True,capture_output=True,timeout=10).stdout.strip()
def run(lane,fmt,files):
 out=R/(lane+'-output');out.mkdir(exist_ok=True);a=['soffice','-env:UserInstallation='+(R/(lane+'-profile')).as_uri(),'--headless','--convert-to',fmt,'--outdir',str(out),*[str(p)for p in files]];start=time.monotonic();r={'argv':a,'timeout_seconds':45}
 try:
  c=subprocess.run(a,text=True,capture_output=True,timeout=45);r.update(exit_code=c.returncode,stdout=c.stdout,stderr=c.stderr)
 except Exception as e:r.update(status='STOP_NO_RETRY',error=repr(e))
 r['seconds']=time.monotonic()-start;dump(lane+'-command.json',r);return lane,r
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:commands=dict(pool.map(lambda a:run(*a),[('calc','xlsx:Calc MS Excel 2007 XML',[fpath]),('pdf','pdf',[CAND])]))
checks=[];formulas=[]
if commands['calc'].get('exit_code')==0:
 out=R/'calc-output/p8-four-month.xlsx';v=openpyxl.load_workbook(out,data_only=True);fw=openpyxl.load_workbook(out,data_only=False);orig=openpyxl.load_workbook(fpath,data_only=False)
 for c in json.loads((B/'checks.json').read_text()):
  if c['lane']!='p8':continue
  got=v[c['sheet']][c['cell']].value;e=c['expected'];passed=(got in [None,'']if e==''else abs(Decimal(str(got))-Decimal(str(e)))<Decimal('0.0000001')if isinstance(got,(float,int))else got==e);checks.append({'sheet':c['sheet'],'cell':c['cell'],'expected':e,'actual':got,'pass':passed})
 for sn in orig.sheetnames:
  for row in orig[sn]:
   for c in row:
    if c.data_type=='f':formulas.append({'sheet':sn,'cell':c.coordinate,'unchanged':fw[sn][c.coordinate].value==c.value})
pdfs=list((R/'pdf-output').glob('*.pdf'));pres=[{'path':n,'before':h,'after':sha(Path(n)),'unchanged':h==sha(Path(n))}for n,h in before.items()];rec={'status':'SCOPED_NUMERIC_PASS_PDF_PENDING_VISUAL'if checks and all(c['pass']for c in checks)and all(f['unchanged']for f in formulas)and all(p['unchanged']for p in pres)and len(pdfs)==1 and commands['pdf'].get('exit_code')==0 else 'STOP_PARTIAL','runtime':version,'numeric_checks':len(checks),'failed':[c for c in checks if not c['pass']],'formula_checks':len(formulas),'changed_formulas':[f for f in formulas if not f['unchanged']],'commands':commands,'preservation':pres,'pdfs':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}for p in pdfs],'api_usd':0};dump('numeric-checks.json',checks);dump('formula-checks.json',formulas);dump('receipt.json',rec);print(rec['status'],len(checks),len(formulas),len(rec['failed']),flush=True)
