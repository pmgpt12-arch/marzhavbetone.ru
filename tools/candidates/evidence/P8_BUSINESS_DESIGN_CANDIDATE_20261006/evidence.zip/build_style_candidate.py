#!/usr/bin/env python3
"""One-book native ZIP style overlay; invoked only after exact contract ACCEPT."""
from pathlib import Path
import copy, hashlib, json, zipfile
import xml.etree.ElementTree as E
import openpyxl

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'local-baseline-preflight/02-kalkulyator-usloviy-avansa.xlsx'
REF=ROOT.parent/'excel-design-reference-20261006/P1_04_Uchet_Business_Design_v1.xlsx'
Q='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
NS={'s':Q[1:-1]}
E.register_namespace('',Q[1:-1])
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    passport=json.loads((ROOT/'passport.json').read_text())
    approval=json.loads((ROOT/'contract-acceptance.json').read_text())
    assert approval['head']==passport['design_contract']['head']
    assert approval['verdict']=='ACCEPT', 'CONTRACT_ACCEPTANCE_REQUIRED'
    assert digest(SOURCE)==passport['source']['sha256']
    assert digest(REF)=='93252d5711cbbd33e682b3f9400fe6ee9aa9ed02c49cf8302ae89976ffc20d77'
    rolemap=json.loads((ROOT/'role-map.json').read_text())
    with zipfile.ZipFile(SOURCE) as a, zipfile.ZipFile(REF) as r:
        styles=E.fromstring(a.read('xl/styles.xml'));reference_styles=E.fromstring(r.read('xl/styles.xml'))
        refbook=openpyxl.load_workbook(REF)
        rs={k:reference_styles.find('s:'+k,NS) for k in ['fonts','fills','borders','cellXfs']}
        ts={k:styles.find('s:'+k,NS) for k in ['fonts','fills','borders','cellXfs']}
        original_xfs=list(ts['cellXfs']); cache={}; changes={}; applied=[]
        roots={name:E.fromstring(a.read(f'xl/worksheets/sheet{index}.xml')) for index,name in enumerate(openpyxl.load_workbook(SOURCE).sheetnames,1)}
        cell_nodes={n:{c.attrib['r']:c for c in root.findall('s:sheetData/s:row/s:c',NS)} for n,root in roots.items()}
        def ref_xf(addr):
            sheet,coord=addr.rsplit('!',1)
            return rs['cellXfs'][refbook[sheet][coord].style_id]
        def append_component(key,node):
            data=E.tostring(node)
            for i,old in enumerate(ts[key]):
                if E.tostring(old)==data:return i
            ts[key].append(copy.deepcopy(node));ts[key].set('count',str(len(ts[key])));return len(ts[key])-1
        def mapped_xf(oldid,role):
            key=(oldid,json.dumps(role,sort_keys=True))
            if key in cache:return cache[key]
            old=original_xfs[oldid]; new=copy.deepcopy(old)
            components=role.get('reference_components') or {k:role['reference'] for k in ['font','fill','border','alignment']}
            for component,group,attribute in [('font','fonts','fontId'),('fill','fills','fillId'),('border','borders','borderId')]:
                addr=components[component]
                if addr=='TARGET preservefont':
                    node=copy.deepcopy(ts[group][int(old.get(attribute,'0'))])
                elif addr.startswith('TARGET'):
                    node=copy.deepcopy(ts[group][int(old.get(attribute,'0'))]);color=node.find('s:color',NS)
                    if color is not None:node.remove(color)
                    E.SubElement(node,Q+'color',{'rgb':'FF27333D'})
                else:
                    xf=ref_xf(addr);node=rs[group][int(xf.get(attribute,'0'))]
                new.set(attribute,str(append_component(group,node)))
            alignment=old.find('s:alignment',NS) if components['alignment']=='TARGET preservealignment' else ref_xf(components['alignment']).find('s:alignment',NS)
            existing=new.find('s:alignment',NS)
            if existing is not None:new.remove(existing)
            if alignment is not None:new.append(copy.deepcopy(alignment));new.set('applyAlignment','1')
            assert new.get('numFmtId')==old.get('numFmtId')
            ts['cellXfs'].append(new);ts['cellXfs'].set('count',str(len(ts['cellXfs'])))
            cache[key]=len(ts['cellXfs'])-1;return cache[key]
        seen=set()
        for role in rolemap['roles']:
            for area in role['range'].split():
                left,top,right,bottom=openpyxl.utils.range_boundaries(area)
                for row in range(top,bottom+1):
                    for col in range(left,right+1):
                        coord=openpyxl.utils.get_column_letter(col)+str(row);identity=(role['sheet'],coord)
                        assert identity not in seen,'OVERLAPPING_ROLE_MAP';seen.add(identity)
                        node=cell_nodes[role['sheet']].get(coord)
                        assert node is not None, 'NO_NEW_CELL_IN_STYLE_ONLY_SCOPE: '+coord
                        before=int(node.get('s','0'));after=mapped_xf(before,role)
                        node.set('s',str(after));applied.append({'sheet':role['sheet'],'cell':coord,'role':role['role'],'old_style':before,'new_style':after})
        changes['xl/styles.xml']=E.tostring(styles,encoding='utf-8')
        for index,name in enumerate(roots,1):changes[f'xl/worksheets/sheet{index}.xml']=E.tostring(roots[name],encoding='utf-8')
        out=ROOT/'02-kalkulyator-usloviy-avansa-Business_Design_candidate.xlsx'
        with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as b:
            for info in a.infolist():b.writestr(copy.copy(info),changes.get(info.filename,a.read(info.filename)))
    # Exact nonstyle gate: normalized XML equal after removing only cell @s.
    checks=[]
    with zipfile.ZipFile(SOURCE) as a, zipfile.ZipFile(out) as b:
        assert a.namelist()==b.namelist();assert b.testzip() is None
        for n in a.namelist():
            aa,bb=a.read(n),b.read(n)
            if n.startswith('xl/worksheets/'):
                ta,tb=E.fromstring(aa),E.fromstring(bb)
                for t in [ta,tb]:
                    for c in t.findall('s:sheetData/s:row/s:c',NS):c.attrib.pop('s',None)
                assert E.tostring(ta)==E.tostring(tb), 'NON_STYLE_SHEET_CHANGE: '+n
                checks.append({'part':n,'non_style_xml_exact':True})
            elif n!='xl/styles.xml':
                assert aa==bb,'UNAUTHORIZED_PART_CHANGE: '+n
                checks.append({'part':n,'exact_bytes':True})
        old,new=E.fromstring(a.read('xl/styles.xml')),E.fromstring(b.read('xl/styles.xml'))
        for group in ['fonts','fills','borders','cellXfs']:
            before,after=old.find('s:'+group,NS),new.find('s:'+group,NS)
            assert all(E.tostring(x)==E.tostring(after[i]) for i,x in enumerate(before))
        oa=openpyxl.load_workbook(SOURCE);ob=openpyxl.load_workbook(out)
        for sn in oa.sheetnames:
            for row in oa[sn]:
                for c in row:
                    d=ob[sn][c.coordinate]
                    assert (c.value,c.data_type,c.number_format,c.protection.locked,c.protection.hidden)==(d.value,d.data_type,d.number_format,d.protection.locked,d.protection.hidden)
        assert digest(SOURCE)==passport['source']['sha256']
    (ROOT/'style-overlay-proof.json').write_text(json.dumps({'status':'NATIVE_STYLE_ONLY_PRESERVATION_PASS','source_sha256':digest(SOURCE),'candidate_sha256':digest(out),'reference_sha256':digest(REF),'applied_cells':len(applied),'checks':checks,'no_new_cells':True,'numformat_protection_semantics_same':True,'source_unchanged':True},indent=2)+'\n')
    (ROOT/'applied-cell-styles.json').write_text(json.dumps(applied,ensure_ascii=False,indent=2)+'\n')
    print('NATIVE_STYLE_ONLY_PRESERVATION_PASS',digest(out),'cells',len(applied))
if __name__=='__main__':main()
