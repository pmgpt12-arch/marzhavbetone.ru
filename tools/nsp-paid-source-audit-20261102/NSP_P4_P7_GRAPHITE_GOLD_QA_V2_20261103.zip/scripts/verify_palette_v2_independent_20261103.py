#!/usr/bin/env python3
"""Independent v2 color + structural gate; no import from either candidate builder."""
import json
import re
import hashlib
import zipfile
import io
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime, timezone

ROOT=Path("/home/denis/projects/nsp-paid-source-audit-20261102/tools/nsp-paid-source-audit-20261102")
LIB=Path("/mnt/server-data/nsp/product-library/accepted-current-20261102/paid")
V2=Path("/mnt/server-data/nsp/operations/qa-style-candidates-v2-20261103")
OUT=V2/"INDEPENDENT_V2_ACCEPTANCE_R2_20261103.json"
NS="{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
PINS={
    "P4":("PAID_P4_current.zip","bcba234220c0f52e5a86b5ba3c70c527d086146301030d1f32197e9fa6e264fc"),
    "P7":("PAID_P7_current.zip","99e877fc851843a79c8524f508529ecab7da049aa6886590fcbce68a97676e24")
}
H=lambda b:hashlib.sha256(b).hexdigest()
FILL=re.compile(rb'(<(?:[a-zA-Z_][\w.-]*:)?fgColor\s+rgb="(?:00|FF))E85D22("\s*/>)')
FONT=re.compile(rb'(<(?:[a-zA-Z_][\w.-]*:)?color\s+rgb="(?:00|FF))E85D22("\s*/>)')

def unzip(data):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        assert z.testzip() is None, "CORRUPTED_ZIP"
        names=z.namelist()
        assert len(names)==len(set(names)),"DUPLICATE_MEMBERS"
        return names,{name:z.read(name) for name in names}

def stats(parts):
    r=ET.fromstring(parts["xl/styles.xml"])
    fonts=r.find(NS+"fonts").findall(NS+"font")
    fills=r.find(NS+"fills").findall(NS+"fill")
    xfs=r.find(NS+"cellXfs").findall(NS+"xf")
    names=[]
    data={"orange_font":[],"orange_fill":[],"gold_font":[],"graphite_fill":[]}
    for sheet_name,payload in parts.items():
        if not re.fullmatch(r"xl/worksheets/sheet\d+\.xml",sheet_name):continue
        for cell in ET.fromstring(payload).iter(NS+"c"):
            sid=int(cell.get("s","0"))
            assert sid<len(xfs),"INVALID_STYLE"
            fmt=xfs[sid]
            f=fonts[int(fmt.get("fontId","0"))]
            color=f.find(NS+"color")
            fcode=(color.get("rgb","")[-6:].upper() if color is not None else "")
            fill=fills[int(fmt.get("fillId","0"))]
            p=fill.find(NS+"patternFill")
            fg=p.find(NS+"fgColor") if p is not None and p.get("patternType")=="solid" else None
            bg=(fg.get("rgb","")[-6:].upper() if fg is not None else "")
            point=(sheet_name,cell.get("r"))
            if fcode=="E85D22":data["orange_font"].append(point)
            if bg=="E85D22":data["orange_fill"].append(point)
            if fcode=="8E6F32":data["gold_font"].append(point)
            if bg=="262F37":data["graphite_fill"].append(point)
    return data

def full_delta_check(source,v1,v2,expected_row3_count):
    n0,a=unzip(source);n1,b=unzip(v1);n2,c=unzip(v2)
    assert n0==n1==n2,"ZIP_MEMBER_SET_ORDER_DRIFT"
    differences1=[n for n in n0 if a[n]!=b[n]]
    differences2=[n for n in n0 if b[n]!=c[n]]
    assert differences1==differences2==["xl/styles.xml"],"OUTSIDE_STYLE_CHANGE"
    assert all(a[name]==b[name]==c[name] for name in n0 if name!="xl/styles.xml"),"NON_STYLE_BYTES_CHANGED"
    s0=a["xl/styles.xml"];s1=b["xl/styles.xml"];s2=c["xl/styles.xml"]
    f=list(FILL.finditer(s0)); assert len(f)==1,"SOURCE_FILL_UNEXPECTED"
    start,end=f[0].span()
    expected1=s0[:start]+f[0].group(1)+b"262F37"+f[0].group(2)+s0[end:]
    assert s1==expected1,"V1_NONFILL_CHANGE"
    t=list(FONT.finditer(s1)); assert len(t)==1,"SOURCE_FONT_UNEXPECTED"
    start,end=t[0].span()
    expected2=s1[:start]+t[0].group(1)+b"8E6F32"+t[0].group(2)+s1[end:]
    assert s2==expected2,"V2_NONFONT_CHANGE"
    st0=stats(a);st1=stats(b);st2=stats(c)
    assert len(st0["orange_fill"])==expected_row3_count,"ORIGINAL_ORANGE_COUNT"
    assert not st1["orange_fill"] and not st2["orange_fill"],"ORANGE_FILL_SURVIVED"
    assert st1["orange_font"]==[("xl/worksheets/sheet2.xml","A1")],"V1_FONT_IDENTITY"
    assert not st2["orange_font"],"ORANGE_FONT_SURVIVED"
    assert ("xl/worksheets/sheet2.xml","A1") in st2["gold_font"],"GOLD_FONT_MISSING"
    expected_addrs={("xl/worksheets/sheet1.xml",f"{chr(65+j)}3") for j in range(expected_row3_count)}
    assert set(st0["orange_fill"])==expected_addrs,"SOURCE_OUTSIDE_ROW3"
    assert expected_addrs.issubset(set(st2["graphite_fill"])),"GRAPHITE_HEADER_MISSING"
    return len(n0),st2

def main():
    assert not OUT.exists(),"RECEIPT_ALREADY_EXISTS"
    vv=json.loads((V2/"V2_GOLD_FONT_CANDIDATES_MANIFEST.json").read_text())
    v1a=json.loads((ROOT/"SEVEN_PALETTE_INDEPENDENT_QA_20261103_R2.json").read_text())
    r1={f["candidate_sha256"]:f for f in v1a["files"]}
    one=json.loads((ROOT/"p4-35a-visual-20261103/candidate/P4-35A-REESTR-GRAPHITE-QA-ONLY.json").read_text())
    six=json.loads((ROOT/"palette-candidates-20261103/SIX_PALETTE_CANDIDATES_RECEIPT.json").read_text())
    v1files={one["candidate_sha256"]:ROOT/"p4-35a-visual-20261103/candidate/P4-35A-REESTR-GRAPHITE-QA-ONLY.xlsx"}
    v1files.update({c["candidate_sha256"]:Path(c["path"]) for c in six["candidates"]})
    assert len(vv["v2_candidates"])==7 and len(r1)==7 and len(v1files)==7
    archive_parts={}
    for sku,(fname,sha) in PINS.items():
        raw=(LIB/fname).read_bytes()
        assert H(raw)==sha,"PINNED_BUYER_ARCHIVE_DRIFT"
        archive_parts[sku]=unzip(raw)[1]
    results=[]
    for c in vv["v2_candidates"]:
        key=c["source_sha256"]
        assert key in r1 and key in v1files,"V1_PROVENANCE_DRIFT"
        ref=r1[key]
        sku=ref["sku"];member=ref["member"]
        src=archive_parts[sku][member]
        v1=v1files[key].read_bytes()
        v2=(V2/c["candidate"]).read_bytes()
        assert H(src)==ref["source_sha256"],"ORIGINAL_MEMBER_SHA_FAIL"
        assert H(v1)==key,"V1_SHA_FAIL"
        assert H(v2)==c["candidate_sha256"],"V2_SHA_FAIL"
        count,post=full_delta_check(src,v1,v2,ref["old_orange_applied_cells"])
        results.append({"sku":sku,"member":member,"v1_sha256":key,"v2_sha256":H(v2),
            "source_sha256":H(src),"member_count":count,"row3_fixed":ref["old_orange_applied_cells"],
            "A1_gold":("xl/worksheets/sheet2.xml","A1") in post["gold_font"],
            "other_uncompressed_parts_byte_identical":True})
    assert len(results)==7 and sum(r["row3_fixed"] for r in results)==76
    # Negative tests are explicitly performed against in-memory mutations, not buyers.
    origin=archive_parts[results[0]["sku"]][results[0]["member"]]
    v1=v1files[results[0]["v1_sha256"]].read_bytes()
    v2=(V2/vv["v2_candidates"][0]["candidate"]).read_bytes()
    def mutate_part(blob,part):
        from copy import copy
        buf=io.BytesIO()
        with zipfile.ZipFile(io.BytesIO(blob)) as src, zipfile.ZipFile(buf,"w") as dst:
            for entry in src.infolist():
                payload=src.read(entry.filename)
                dst.writestr(copy(entry),payload+b" " if entry.filename==part else payload)
        return buf.getvalue()
    test_results={}
    for label,part,expected_error in [
        ("non_style_mutation","xl/worksheets/sheet1.xml","OUTSIDE_STYLE_CHANGE"),
        ("unrelated_style_mutation","xl/styles.xml","V2_NONFONT_CHANGE")
    ]:
        mutant=mutate_part(v2,part)
        assert unzip(mutant)[0]==unzip(v2)[0],label
        try:
            full_delta_check(origin,v1,mutant,results[0]["row3_fixed"])
        except AssertionError as e:
            assert expected_error in str(e),(label,str(e))
            test_results[label]="PASS_REJECTED"
        else:
            raise AssertionError("NEGATIVE_MUTATION_NOT_DETECTED:"+label)
    assert not OUT.exists()
    data={"schema":"NSP_QA_V2_INDEPENDENT_EXACT_ACCEPTANCE_v2","checked_utc":datetime.now(timezone.utc).isoformat(),
       "status":"SEVEN_EXACT_STYLE_ONLY_STATIC_PASS_NATIVE_PENDING",
       "file_count":7,"header_cells_corrected":76,"instruction_title_cells_corrected":7,
       "orange_applied_cells_remaining":0,"non_style_parts_changed":0,
       "source_archives_sha256":{k:v[1] for k,v in PINS.items()},
       "negative_gate_tests":test_results,
       "native_office_final_sha":"PENDING","release_allowed":False,"buyer_archive_modified":False,
       "records":results}
    OUT.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n")
    assert json.loads(OUT.read_text())["status"]==data["status"]
    print(json.dumps({"status":data["status"],"files":7,"orange_left":0,"font_titles":7,
        "header_cells":76,"receipt":str(OUT)},ensure_ascii=False))
if __name__=="__main__":main()
