<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') exit(1);
function must(bool $ok,string $why):void {if(!$ok)throw new RuntimeException($why);}
function h(string $path):string {must(is_file($path)&&!is_link($path),'UNSAFE_FILE:'.basename($path));return (string)hash_file('sha256',$path);}
function files(string $dir):array {
    must(is_dir($dir)&&!is_link($dir),'INVALID_DIR');
    $out=[];
    foreach(new DirectoryIterator($dir) as $f) {
        if($f->isDot())continue;
        must($f->isFile()&&!$f->isLink(),'INVALID_MEMBER');
        $out[$f->getFilename()]=h($f->getPathname());
    }
    ksort($out);return $out;
}
function atomic_bytes(string $target,string $bytes):void {
    $p=tempnam(dirname($target),'.nsp-scoped-');must(is_string($p),'TEMP_FAILED');
    $mode=is_file($target)?fileperms($target)&0777:0644;
    try {
        must(file_put_contents($p,$bytes,LOCK_EX)===strlen($bytes),'TEMP_WRITE');
        chmod($p,$mode);must(rename($p,$target),'RENAME_FAILED');
    }finally{if(is_file($p))unlink($p);}
}
function php_patch(string $config,string $payment,array $m):array {
    foreach(['p4','p5'] as $sku) {
        $p=$m['products'][$sku];$old=$p['old_zip_sha256'];$new=$p['new_zip_sha256'];
        must(substr_count($config,$old)===1,'PHP_SHA_ANCHOR:'.$sku);
        $config=str_replace($old,$new,$config,$count);must($count===1,'PHP_SHA_CHANGE');
        $a='/'.$p['old_master'];$b='/'.$p['new_master'];
        must(substr_count($config,$a)===1,'PHP_MASTER_ANCHOR:'.$sku);
        $config=str_replace($a,$b,$config,$count);must($count===1,'PHP_MASTER_CHANGE');
    }
    must(substr_count($config,"'p4' => '00-START-HERE.txt'")===1,'P4_MAIL_START_ANCHOR');
    $config=str_replace("'p4' => '00-START-HERE.txt'","'p4' => '00-INSTRUKCIYA.pdf'",$config);
    must(substr_count($config,"'p4' => '00-INSTRUKCIYA.pdf', 'p7' =>")===1,'P5_MAIL_START_ANCHOR');
    $config=str_replace("'p4' => '00-INSTRUKCIYA.pdf', 'p7' =>","'p4' => '00-INSTRUKCIYA.pdf', 'p5' => '00-START-HERE.pdf', 'p7' =>",$config);
    must(!str_contains($payment,'nsp_retired_new_order_guard_20261102'),'PAYMENT_ALREADY_PATCHED');
    $anchor='// Издание P1 фиксируется до заказа и обращения к кассе.';
    must(substr_count($payment,$anchor)===1,'PAYMENT_INSERT_ANCHOR');
    $guard=<<<'PHPGUARD'
// nsp_retired_new_order_guard_20261102 — новые T2/T3 запрещены, историческая выдача не изменяется.
foreach ($validatedItems as $position) {
    if (in_array((string)($position['sku'] ?? ''), ['t2','t3'], true)) {
        http_response_code(409);
        echo json_encode(['ok'=>false,'message'=>'Материалы включены в полные системы P4/P5. Выберите актуальный комплект.'],JSON_UNESCAPED_UNICODE);
        exit;
    }
}

PHPGUARD;
    $payment=str_replace($anchor,$guard.$anchor,$payment,$count);
    must($count===1,'PAYMENT_PATCH_COUNT');
    token_get_all($config,TOKEN_PARSE);token_get_all($payment,TOKEN_PARSE);
    return [$config,$payment];
}
$mode=$argv[1]??'';must(in_array($mode,['preflight','apply','verify','rollback','read-current'],true),'INVALID_MODE');
$site=realpath($argv[2]??'');$stage=realpath($argv[3]??'');
must(is_string($site)&&is_string($stage)&&basename($site)==='nastoronepodryadchika.ru','SITE_STAGE_IDENTITY');
must(!str_starts_with($stage,$site.'/'),'STAGE_IN_PUBLIC_SITE');
$m=json_decode((string)file_get_contents($stage.'/release.json'),true,512,JSON_THROW_ON_ERROR);
must(($m['schema']??'')==='NSP_P4P5_SCOPED_RELEASE_V1'&&count($m['static'])===18,'MANIFEST_SCOPE');
must($m['delivery_ttl']===3600&&count($m['products'])===2,'MANIFEST_PRODUCTS');
require $site.'/config.php';
require $site.'/products-config.php';
$catalog=mvb_products();$root=realpath(PRODUCTS_DIR);$delivery=realpath(DELIVERY_DIR);
must(is_string($root)&&is_string($delivery)&&!str_starts_with($root,$site.'/'),'PRIVATE_ROOT');
must(DELIVERY_TTL_SECONDS===3600,'TTL');
$tag=basename($stage);must((bool)preg_match('/^[A-Za-z0-9-]{8,90}$/D',$tag),'STAGE_TAG');
$backup=$stage.'/rollback';
function source_paths(array $p,string $sku):array {
    global $root,$delivery,$tag;
    return ['source'=>$root.'/'.$p['dir'],'cache'=>$delivery.'/'.$p['zip'],
      'new_master'=>$root.'/'.$p['new_master'],'old_master'=>$root.'/'.$p['old_master'],
      'newdir'=>$root.'/.nsp-new-'.$sku.'-'.$tag,
      'olddir'=>$root.'/.nsp-old-'.$sku.'-'.$tag];
}
function inspect_before():void {
    global $m,$site,$stage,$catalog,$root,$delivery;
    must(h($site.'/products-config.php')===$m['production_php_before']['products-config.php'],'PHP_CONFIG_DRIFT');
    must(h($site.'/payment.php')===$m['production_php_before']['payment.php'],'PAYMENT_DRIFT');
    foreach($m['static'] as $r){
        must((bool)preg_match('~^(?:articles/|materialy/|products/)?[a-zA-Z0-9_-]+\.(?:html|xml)$~D',$r['path']),'STATIC_BAD_PATH');
        must(h($site.'/'.$r['path'])===$r['before'],'STATIC_LIVE_DRIFT:'.$r['path']);
        must(h($stage.'/pages/'.$r['path'])===$r['after'],'STATIC_SOURCE_BAD:'.$r['path']);
    }
    foreach(['p4','p5'] as $sku) {
        $v=$m['products'][$sku];$paths=source_paths($v,$sku);
        $old=$v['old_members'];ksort($old);must(files($paths['source'])===$old,'SOURCE_DRIFT:'.$sku);
        must(h($paths['cache'])===$v['old_cache_sha256'],'CACHE_DRIFT:'.$sku);
        must(h($paths['old_master'])===$v['old_zip_sha256'],'MASTER_DRIFT:'.$sku);
        foreach(['new_master','newdir','olddir'] as $key) must(!file_exists($paths[$key]),'STAGING_PRESENT:'.$key);
        must($catalog[$sku]['dir']===$v['dir']&&$catalog[$sku]['zip']===$v['zip']&&$catalog[$sku]['price']===$v['price'],'CATALOG_DRIFT:'.$sku);
        $zip=$stage.'/archives/'.$sku.'.zip';must(h($zip)===$v['new_zip_sha256'],'NEW_ZIP_SHA:'.$sku);
        $z=new ZipArchive();must($z->open($zip)===true,'ZIP_OPEN');must($z->numFiles===30,'ZIP_COUNT');
        $members=[];for($i=0;$i<$z->numFiles;$i++){$n=$z->getNameIndex($i);must(basename($n)===$n&&!isset($members[$n]),'ZIP_UNSAFE_NAME');$members[$n]=hash('sha256',(string)$z->getFromIndex($i));}
        $z->close();ksort($members);$expected=$v['new_members'];ksort($expected);must($members===$expected,'ZIP_MEMBERS');
    }
    foreach(['t2','t3'] as $sku){
        $v=$m['legacy'][$sku];$p=$catalog[$sku];must($p['dir']===$v['dir']&&$p['zip']===$v['zip']&&$p['price']===$v['price'],'LEGACY_SKU_DRIFT');
        $e=$v['files'];ksort($e);must(files($root.'/'.$p['dir'])===$e,'LEGACY_FILES_DRIFT');
        must(h($delivery.'/'.$p['zip'])===$v['cache_sha256'],'LEGACY_CACHE_DRIFT');
    }
}
function inspect_after():void {
    global $m,$site,$stage,$catalog,$root,$delivery;
    must(h($site.'/products-config.php')===h($stage.'/config-new.php'),'CONFIG_NEW_SHA');
    must(h($site.'/payment.php')===h($stage.'/payment-new.php'),'PAYMENT_NEW_SHA');
    foreach($m['static'] as $r)must(h($site.'/'.$r['path'])===$r['after'],'STATIC_AFTER:'.$r['path']);
    foreach(['p4','p5'] as $sku) {
        $v=$m['products'][$sku];$paths=source_paths($v,$sku);
        $e=$v['new_members'];ksort($e);must(files($paths['source'])===$e,'NEW_SOURCE_DRIFT');
        must(h($paths['new_master'])===$v['new_zip_sha256'],'NEW_MASTER_DRIFT');
        must(h($paths['cache'])===$v['new_zip_sha256'],'NEW_CACHE_DRIFT');
        must(is_dir($paths['olddir']),'OLD_SOURCE_NOT_PRESERVED');
        $old=$v['old_members'];ksort($old);must(files($paths['olddir'])===$old,'OLD_SOURCE_CHANGED');
    }
    foreach(['t2','t3'] as $sku){
        $v=$m['legacy'][$sku];$p=$catalog[$sku];$e=$v['files'];ksort($e);
        must(files($root.'/'.$p['dir'])===$e,'LEGACY_SOURCE_CHANGED');
        must(h($delivery.'/'.$p['zip'])===$v['cache_sha256'],'LEGACY_CACHE_CHANGED');
    }
}
function rollback_assets():void {
    global $m,$site,$stage,$backup,$root,$delivery;
    if(!is_dir($backup))return;
    foreach($m['static'] as $r){
        $dst=$site.'/'.$r['path'];$old=$backup.'/pages/'.$r['path'];
        if(!is_file($old))continue;
        $now=h($dst);
        if($now===$r['after'])atomic_bytes($dst,(string)file_get_contents($old));
        elseif($now!==$r['before'])throw new RuntimeException('ROLLBACK_STATIC_FOREIGN_EDIT');
    }
    foreach(['payment.php','products-config.php'] as $file){
        $dst=$site.'/'.$file;$old=$backup.'/'.$file;
        if(is_file($old)&&h($dst)!==h($old)) {
            $new=$stage.'/'.($file==='payment.php'?'payment-new.php':'config-new.php');
            must(h($dst)===h($new),'ROLLBACK_PHP_FOREIGN_EDIT');
            atomic_bytes($dst,(string)file_get_contents($old));
        }
    }
    foreach(['p4','p5'] as $sku){
        $v=$m['products'][$sku];$path=source_paths($v,$sku);
        if(is_file($backup.'/cache-'.$sku.'.zip')&&h($path['cache'])===$v['new_zip_sha256'])
            atomic_bytes($path['cache'],(string)file_get_contents($backup.'/cache-'.$sku.'.zip'));
        if(is_dir($path['olddir'])) {
            if(is_dir($path['source'])){
                $e=$v['new_members'];ksort($e);must(files($path['source'])===$e,'ROLLBACK_SOURCE_FOREIGN_EDIT');
                must(rename($path['source'],$path['newdir']),'ROLLBACK_NEW_RENAME');
            }
            must(rename($path['olddir'],$path['source']),'ROLLBACK_RESTORE_SOURCE');
        }
        if(is_file($path['new_master'])&&h($path['new_master'])===$v['new_zip_sha256'])unlink($path['new_master']);
    }
}
try {
 if($mode==='preflight'||$mode==='apply') {
    inspect_before();
    [$config,$payment]=php_patch((string)file_get_contents($site.'/products-config.php'),(string)file_get_contents($site.'/payment.php'),$m);
    if($mode==='preflight') {
        must(!is_dir($backup),'EXISTING_BACKUP');
        file_put_contents($stage.'/config-new.php',$config,LOCK_EX);
        file_put_contents($stage.'/payment-new.php',$payment,LOCK_EX);
        echo json_encode(['status'=>'PREFLIGHT_PASS','scope'=>'P4_P5_18_STATIC_AND_RETIRE_NEW_T2_T3','files'=>18,'new_zip_members'=>60,'production_writes'=>false]),"\n";exit;
    }
    must(!is_dir($backup),'APPLY_ALREADY_STARTED');
    must(h($stage.'/config-new.php')===hash('sha256',$config)&&h($stage.'/payment-new.php')===hash('sha256',$payment),'PREFLIGHT_PHP_CHANGED');
    mkdir($backup,0700);
    foreach(['products-config.php','payment.php'] as $name) {
        must(copy($site.'/'.$name,$backup.'/'.$name),'BACKUP_PHP');
        chmod($backup.'/'.$name,0600);
    }
    mkdir($backup.'/pages',0700);
    foreach($m['static'] as $r){
        $dst=$backup.'/pages/'.$r['path'];if(!is_dir(dirname($dst)))mkdir(dirname($dst),0700,true);
        must(copy($site.'/'.$r['path'],$dst),'BACKUP_STATIC');must(h($dst)===$r['before'],'BACKUP_STATIC_HASH');
    }
    foreach(['p4','p5'] as $sku){
        $v=$m['products'][$sku];$path=source_paths($v,$sku);
        must(copy($path['cache'],$backup.'/cache-'.$sku.'.zip'),'BACKUP_CACHE');
        must(h($backup.'/cache-'.$sku.'.zip')===$v['old_cache_sha256'],'BACKUP_CACHE_HASH');
        must(mkdir($path['newdir'],0755),'NEW_DIR');
        $z=new ZipArchive();must($z->open($stage.'/archives/'.$sku.'.zip')===true,'NEW_ZIP_OPEN');
        foreach($v['new_members'] as $name=>$hash){
            $bytes=$z->getFromName($name);must(is_string($bytes)&&hash('sha256',$bytes)===$hash,'EXTRACT_HASH');
            must(file_put_contents($path['newdir'].'/'.$name,$bytes)===strlen($bytes),'EXTRACT_WRITE');
            chmod($path['newdir'].'/'.$name,0644);
        }
        $z->close();$expected=$v['new_members'];ksort($expected);must(files($path['newdir'])===$expected,'NEW_DIR_HASH');
    }
    // All rollback material is now present before the first production write.
    foreach(['p4','p5'] as $sku){
        $v=$m['products'][$sku];$path=source_paths($v,$sku);
        atomic_bytes($path['new_master'],(string)file_get_contents($stage.'/archives/'.$sku.'.zip'));
        must(h($path['new_master'])===$v['new_zip_sha256'],'MASTER_WRITE_HASH');
        must(rename($path['source'],$path['olddir']),'OLD_SOURCE_MOVE');
        must(rename($path['newdir'],$path['source']),'NEW_SOURCE_MOVE');
        atomic_bytes($path['cache'],(string)file_get_contents($stage.'/archives/'.$sku.'.zip'));
        must(h($path['cache'])===$v['new_zip_sha256'],'CACHE_WRITE_HASH');
    }
    atomic_bytes($site.'/products-config.php',$config);
    atomic_bytes($site.'/payment.php',$payment);
    foreach($m['static'] as $r)atomic_bytes($site.'/'.$r['path'],(string)file_get_contents($stage.'/pages/'.$r['path']));
    inspect_after();
    echo json_encode(['status'=>'APPLIED_PENDING_INDEPENDENT_VERIFY','archives'=>2,'pages'=>18,'protected_legacy'=>'UNCHANGED']),"\n";exit;
 }
 if($mode==='verify'){
    inspect_after();
    foreach(['p4','p5'] as $sku){
        $p=mvb_build_product_zip($sku);$v=$m['products'][$sku];
        must(is_string($p)&&h($p)===$v['new_zip_sha256'],'LIVE_DELIVERY_BUILDER:'.$sku);
    }
    echo json_encode(['status'=>'PRODUCTION_SOURCES_BUILDER_AND_PAGES_VERIFIED','p4'=>$m['products']['p4']['new_zip_sha256'],'p5'=>$m['products']['p5']['new_zip_sha256'],'legacy'=>'PRESERVED','ttl'=>3600]),"\n";exit;
 }
 if($mode==='read-current'){
    inspect_after();
    $sku=$argv[4]??'';must(in_array($sku,['p4','p5'],true),'READ_CURRENT_SKU');
    $path=$delivery.'/'.$m['products'][$sku]['zip'];
    must(h($path)===$m['products'][$sku]['new_zip_sha256'],'READ_CURRENT_SHA');
    readfile($path);exit;
 }
 if($mode==='rollback'){
    rollback_assets();
    must(h($site.'/products-config.php')===$m['production_php_before']['products-config.php'],'ROLLBACK_CONFIG_HASH');
    must(h($site.'/payment.php')===$m['production_php_before']['payment.php'],'ROLLBACK_PAYMENT_HASH');
    foreach($m['static'] as $r)must(h($site.'/'.$r['path'])===$r['before'],'ROLLBACK_STATIC_HASH');
    foreach(['p4','p5'] as $sku){
       $v=$m['products'][$sku];$paths=source_paths($v,$sku);
       $old=$v['old_members'];ksort($old);
       must(files($paths['source'])===$old,'ROLLBACK_SOURCE_INVENTORY');
       must(h($paths['cache'])===$v['old_cache_sha256'],'ROLLBACK_CACHE_HASH');
       must(h($paths['old_master'])===$v['old_zip_sha256'],'ROLLBACK_MASTER_HASH');
    }
    echo "{\"status\":\"ROLLBACK_VERIFIED\"}\n";exit;
 }
}catch(Throwable $e){
    if($mode==='apply'&&is_dir($backup)) {
        try{rollback_assets();fwrite(STDERR,"AUTO_ROLLBACK_EXECUTED\n");}
        catch(Throwable $r){fwrite(STDERR,"ROLLBACK_BLOCKED=".$r->getMessage()."\n");}
    }
    fwrite(STDERR,"NSP_SCOPED_RELEASE_FAIL=".$e->getMessage()."\n");exit(1);
}
