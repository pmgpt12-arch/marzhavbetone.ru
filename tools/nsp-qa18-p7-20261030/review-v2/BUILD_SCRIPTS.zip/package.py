from pathlib import Path
from docx import Document
import json,re,zipfile,hashlib
R=Path(__file__).resolve().parent;O=R/'candidate';I=R/'internal';H=lambda b:hashlib.sha256(b).hexdigest()
d=Document(O/'01-dogovor-subpodryada.docx');a=Document(O/'11-obrazec-dogovora-s-poyasneniyami.docx');clauses=[p.text for p in d.paragraphs if re.match(r'[1-8]\.\d+\.',p.text)];assert all(t in [p.text for p in a.paragraphs]for t in clauses)
sections=json.loads((I/'SECTION_MAP.json').read_text());assert len(sections)==9
for s in sections:assert all(s[k]for k in ['find','risk','proposal','evidence'])
unchanged=[]
for f in O.iterdir():
 if f.name not in ['00-INSTRUKCIYA.pdf','01-dogovor-subpodryada.docx','11-obrazec-dogovora-s-poyasneniyami.docx','12-karta-riskov-dogovora.docx']:
  assert f.read_bytes()==(R.parent/'qa18-p7/candidate'/f.name).read_bytes();unchanged.append(f.name)
assert sum(f.endswith('.xlsx')for f in unchanged)==3
m=json.loads((I/'REVIEW_MANIFEST.json').read_text());assert m['rendered_pages']==42 and m['file_count']==13
receipt={'status':'SCOPED_ACCEPTANCE_PASS','clean_specimen_numbered_clauses_exactly_present_in_annotation':len(clauses),'annotated_sections':9,'unchanged_files':unchanged,'visual_review':'All changed pages inspected; unchanged views covered by predecessor exact-byte receipts. New title borders removed and final title/form pages inspected.','reference_form_access':'Catalog presence confirmed; full paywalled forms not read or incorporated','legal_sources_checked':'2026-10-30','new_native_office_run':False,'production_changed':False,'full_qa_pass':False,'build_gate':'build.py requires v1 input; refuses v2 rerun to prevent duplicate termination clauses'}
(I/'ACCEPTANCE_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
m.update(status='READY_FOR_OWNER_REVIEW',product_title='Договор подряда: корректируем в интересах исполнителя',acceptance=receipt,predecessor_archive_sha256='da4adaa0c7bbb37d830a23e36de83273a8e8128c34894bed2522b40253897bc4',predecessor_evidence_commit='b015dd1aa250b6f8fb95255d798199189ceed0e8',reference_research_commit='f210e279d31a9bc44a29c12195753bd579a2dc11')
p=R/'output/P7_Dogovor_v_interesah_ispolnitelya_v2.zip'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED)as z:
 for f in sorted(O.iterdir()):
  info=zipfile.ZipInfo(f.name,(2026,10,30,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,f.read_bytes())
with zipfile.ZipFile(p)as z:assert z.testzip()is None and len(z.namelist())==13 and all(H(z.read(x['name']))==x['sha256']for x in m['files'])
m['archive']={'name':p.name,'sha256':H(p.read_bytes()),'bytes':p.stat().st_size};(I/'REVIEW_MANIFEST.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));print(json.dumps({'archive':m['archive'],'preview':m['preview']}))
