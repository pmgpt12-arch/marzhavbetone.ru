from pathlib import Path
from docx import Document
from docx.shared import RGBColor,Pt
from docx.oxml.ns import qn
R=Path(__file__).resolve().parent
for code in ['01','11','12']:
 f=next((R/'candidate').glob(code+'*.docx'));d=Document(f)
 for s in d.styles:
  if s.name in ['Title','Subtitle']or s.name.startswith('Heading'):
   s.font.color.rgb=RGBColor(0,0,0)
  pr=s.element.find(qn('w:pPr'))
  if pr is not None:
   for b in list(pr.findall(qn('w:pBdr'))):pr.remove(b)
 for p in d.paragraphs:
  pr=p._p.get_or_add_pPr()
  for b in list(pr.findall(qn('w:pBdr'))):pr.remove(b)
  if code=='01'and(p.text.startswith('8. ')or p.text.startswith('9. ')):
   p.style='Heading 1'
   for run in p.runs:run.font.size=Pt(10.5);run.font.color.rgb=RGBColor(0,0,0)
 d.save(f)
print('New headings normalized')
