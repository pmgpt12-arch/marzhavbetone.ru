from pathlib import Path
from lxml import etree as E
import zipfile,json
R=Path(__file__).resolve().parent;ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main';q=lambda n:'{'+ns+'}'+n
receipt=[]
for f in (R.parent/'outputs/qa18-p7').glob('*.xlsx'):
 with zipfile.ZipFile(f)as z:parts={n:z.read(n)for n in z.namelist()}
 w=E.fromstring(parts['xl/workbook.xml']);defs=w.find(q('definedNames'))
 if defs is None:defs=E.SubElement(w,q('definedNames'))
 for e in list(defs):
  if e.get('name') in ['_xlnm.Print_Area','_xlnm.Print_Titles']:defs.remove(e)
 last='J'if f.name.startswith('05')else'I'
 for i,title in enumerate(['Реестр','Инструкция']):
  a=E.SubElement(defs,q('definedName'),name='_xlnm.Print_Area',localSheetId=str(i));a.text="'"+title+"'!$A$1:$"+(last+'$106'if i==0 else'A$3')
  if i==0:
   a=E.SubElement(defs,q('definedName'),name='_xlnm.Print_Titles',localSheetId='0');a.text="'Реестр'!$1:$3"
  p='xl/worksheets/sheet'+str(i+1)+'.xml';s=E.fromstring(parts[p]);ps=s.find(q('pageSetup'))
  if ps is None:ps=E.SubElement(s,q('pageSetup'))
  ps.attrib.update({'paperSize':'9','orientation':'landscape'if i==0 else'portrait','fitToWidth':'1','fitToHeight':'0'})
  sp=s.find(q('sheetPr'))
  if sp is None:sp=E.Element(q('sheetPr'));s.insert(0,sp)
  pp=sp.find(q('pageSetUpPr'))
  if pp is None:pp=E.SubElement(sp,q('pageSetUpPr'))
  pp.set('fitToPage','1')
  pm=s.find(q('pageMargins'))
  if pm is None:pm=E.SubElement(s,q('pageMargins'))
  pm.attrib.update({'left':'0.25','right':'0.25','top':'0.35','bottom':'0.35','header':'0.15','footer':'0.15'})
  parts[p]=E.tostring(s,xml_declaration=True,encoding='UTF-8',standalone=True)
 parts['xl/workbook.xml']=E.tostring(w,xml_declaration=True,encoding='UTF-8',standalone=True)
 out=R/'candidate'/f.name
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED)as z:
  for n,b in parts.items():z.writestr(n,b)
 receipt.append({'name':f.name,'authoring':'Artifact Tool','print_metadata':'OOXML fallback; same unsupported print API surface established in QA17','formula_count':0})
(R/'internal/EXCEL_BUILD_RECEIPT.json').write_text(json.dumps(receipt,indent=2));print(receipt)
