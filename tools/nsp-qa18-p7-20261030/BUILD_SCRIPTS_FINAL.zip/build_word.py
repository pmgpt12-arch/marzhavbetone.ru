from pathlib import Path
from docx import Document
from docx.shared import Pt,RGBColor,Twips
from docx.oxml.ns import qn
from layout_helpers import norm,elem
import shutil,json
R=Path(__file__).resolve().parent;S=R/'source';O=R/'candidate';changes=[]
for f in S.glob('*.pdf'):
 if not f.name.startswith('00'):shutil.copyfile(f,O/f.name)
for f in S.glob('*.docx'):
 if f.name.startswith('00'):continue
 d=Document(f)
 # Full-width party details are independent of full-width signature blocks.
 details=[p for p in d.paragraphs if p.text.startswith(('Генподрядчик: {{ПОЛНОЕ','Субподрядчик: {{ПОЛНОЕ'))]
 if details:
  t=d.add_table(rows=len(details),cols=1);details[0]._p.addprevious(t._tbl)
  for row,p in zip(t.rows,details):row.cells[0].text=p.text;p._p.getparent().remove(p._p)
 for t in list(d.tables):
  if len(t.columns)==2 and len(t.rows)==1 and 'Подпись' in t.cell(0,0).text:
   texts=[t.cell(0,i).text for i in range(2)];new=d.add_table(rows=4,cols=1);t._tbl.addprevious(new._tbl)
   for i,txt in enumerate(texts):
    lines=txt.splitlines();new.cell(i*2,0).text='\n'.join(lines[:2]);new.cell(i*2+1,0).text='\n'.join(lines[2:])
   t._tbl.getparent().remove(t._tbl)
 for p in d.paragraphs:
  p.paragraph_format.page_break_before=False
  for br in list(p._p.xpath('.//w:br[@w:type="page"]')):br.getparent().remove(br)
  if f.name.startswith('01') and p.text.startswith('1.3.'):
   p.text='1.3. При обнаружении неучтённых в технической документации работ и необходимости дополнительных работ с увеличением сметной стоимости Субподрядчик уведомляет Генподрядчика об объёме, цене и влиянии на сроки. При неполучении ответа в течение 10 дней, если иной срок не предусмотрен законом или договором, соответствующие работы приостанавливаются в порядке п. 3 ст. 743 ГК РФ. Неисполнение обязанности уведомить влечёт последствия п. 4 ст. 743 ГК РФ, с предусмотренным им исключением для необходимых немедленных действий в интересах заказчика. Согласованные изменения цены, объёма и сроков оформляются письменно; обстоятельства немедленных действий и доказательства фиксируются отдельно.'
  if f.name.startswith('01') and p.text.startswith('2.1.'):
   p.text=p.text+' Состав, содержание, сторона и срок передачи технической документации определены перечнем по п. 1.2 и настоящим пунктом.'
  if p.text.strip() and (p.style.name=='Title' or p.text.isupper()):
   p.style='Title'
  p.paragraph_format.space_after=Pt(5);p.paragraph_format.line_spacing=1.05
  for run in p.runs:run.font.name='Arial';run.font.color.rgb=RGBColor(0,0,0)
 norm(d)
 for style in [d.styles['Normal'],d.styles['Title']]:
  style.font.name='Arial';style.font.color.rgb=RGBColor(0,0,0)
  pr=style.element.find(qn('w:pPr'))
  if pr is not None:
   for b in list(pr.findall(qn('w:pBdr'))):pr.remove(b)
 d.styles['Normal'].font.size=Pt(10.5);d.styles['Title'].font.size=Pt(14)
 for t in d.tables:
  if len(t.columns)==4:
   widths=[1450,2400,3200,2816]
   for col,width in zip(t.columns,widths):col.width=Twips(width)
   for tr in t._tbl.tr_lst:
    for tc,width in zip(tr.tc_lst,widths):elem(tc.get_or_add_tcPr(),'w:tcW',{'w:type':'dxa','w:w':width})
  for row in t.rows:
   for cell in row.cells:
    for p in cell.paragraphs:
     for run in p.runs:run.font.name='Arial'
  prev=t._tbl.getprevious()
  if prev is not None and prev.tag==qn('w:tbl'):
   from docx.oxml import OxmlElement
   t._tbl.addprevious(OxmlElement('w:p'))
 d.save(O/f.name);changes.append({'name':f.name,'tables':len(d.tables)})
(R/'internal/WORD_BUILD_RECEIPT.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2));print(changes)
