from pathlib import Path
import fitz,json,hashlib,zipfile
from collections import Counter
from docx import Document
from docx.oxml.ns import qn
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;O=R/'candidate';I=R/'internal';H=lambda b:hashlib.sha256(b).hexdigest();files=sorted(O.iterdir());assert len(files)==11;assert Counter(f.suffix for f in files)=={'.docx':5,'.xlsx':3,'.pdf':3};assert [x.name for x in files if x.name.startswith('00')]==['00-INSTRUKCIYA.pdf']
for f in O.glob('*.docx'):
 d=Document(f)
 for t in d.tables:
  assert t._tbl.tblPr.find(qn('w:tblW')).get(qn('w:w'))=='9866'
  assert sum(int(c.get(qn('w:w')))for c in t._tbl.tblGrid)==9866
 for t in d.tables:
  for tr in t._tbl.tr_lst:
   for h in tr.xpath('./w:trPr/w:trHeight'):assert h.get(qn('w:hRule'))!='exact'
for code in ['08','09']:
 f=next(O.glob(code+'*.pdf'));assert H(f.read_bytes())==H((R/'source'/f.name).read_bytes())
preview=fitz.open();mapping=[];imgs=[];v=I/'visual';v.mkdir(exist_ok=True)
for f in files:
 p=f if f.suffix=='.pdf'else R/('render-word/'+f.stem+'/'+f.stem+'.pdf'if f.suffix=='.docx'else'render-excel/'+f.stem+'.pdf');d=fitz.open(p)
 assert all(x.get_text().strip()for x in d)
 mapping.append({'file':f.name,'from_page':len(preview)+1,'pages':len(d),'sha256':H(f.read_bytes()),'render_sha256':H(p.read_bytes())});preview.insert_pdf(d)
 for i,page in enumerate(d):
  pix=page.get_pixmap();im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);dest=v/(f.stem+'-'+str(i+1)+'.png');im.save(dest);imgs.append((f.name,i+1,im))
contacts=[]
for start in range(0,len(imgs),4):
 chunk=imgs[start:start+4];w=max(x[2].width for x in chunk)+12;h=max(x[2].height for x in chunk)+26;canvas=Image.new('RGB',(w*2,h*2),'#ddd');dr=ImageDraw.Draw(canvas)
 for i,(name,page,im)in enumerate(chunk):x=i%2*w;y=i//2*h;dr.text((x+3,y+3),name+' p'+str(page),fill='black');canvas.paste(im,(x,y+23))
 p=v/('contact-'+str(start//4+1)+'.png');canvas.save(p);contacts.append(str(p))
out=R/'output'/('P7_predprosmotr_'+str(len(preview))+'str.pdf');preview.save(out,garbage=4,deflate=True)
m={'sku':'p7','edition':'P7-layout-v1','status':'AWAITING_VISUAL_REVIEW','source_commit':'5361c80125107d9bb47d355bd5730f8b6e2da2c1','source_archive_sha256':H((R/'source.zip').read_bytes()),'file_count':11,'formats':{'docx':5,'xlsx':3,'pdf':3},'rendered_pages':len(preview),'render_map':mapping,'contacts':contacts,'preview':{'name':out.name,'sha256':H(out.read_bytes())},'new_native_office_test_performed':False,'render_engine':'LibreOffice','owner_approval':'PENDING','release_allowed':False,'production_changed':False,'full_qa_pass':False,'files':[{'name':f.name,'sha256':H(f.read_bytes()),'bytes':f.stat().st_size}for f in files]};(I/'REVIEW_MANIFEST.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));print(json.dumps({'pages':len(preview),'mapping':[(x['file'],x['pages'])for x in mapping],'contacts':len(contacts)},ensure_ascii=False))
