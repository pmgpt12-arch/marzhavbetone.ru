from pathlib import Path
import fitz,json,hashlib,zipfile,re
from openpyxl import load_workbook
R=Path(__file__).resolve().parent;H=lambda b:hashlib.sha256(b).hexdigest();norm=lambda s:re.sub(r'\s+','',str(s)).replace('\u00ad','');checks=[]
for f in (R/'candidate').glob('*.xlsx'):
 a=load_workbook(f);b=load_workbook(R/'source'/f.name);assert a.sheetnames==b.sheetnames
 txt=norm(''.join(p.get_text()for p in fitz.open(R/'render-excel'/(f.stem+'.pdf'))))
 for sh,old in zip(a,b):
  assert set(str(x)for x in sh.merged_cells)==set(str(x)for x in old.merged_cells)
  assert str(sh.data_validations)==str(old.data_validations)
  for row in old:
   for c in row:
    val=sh[c.coordinate].value
    if val!=c.value:
     assert (sh.title=='Инструкция'and c.coordinate=='A3')or(sh.title=='Реестр'and c.coordinate in (['E3']if f.name.startswith('03')else['C3','D3','E3','F3','G3','H3','I3','J3']))
  for row in sh:
   for c in row:
    assert c.data_type!='f'
    if c.value is not None:assert norm(c.value)in txt,(f.name,c.coordinate,c.value)
 checks.append({'file':f.name,'values_changes_scoped':True,'all_nonempty_text_printed':True,'no_formula_source_or_candidate':True,'merged_cells_and_validations_preserved':True})
(R/'internal/EXCEL_PRESERVATION.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
# Manual reconciliation of the guide example, independent from any template formulas.
assert 500000-100000-25000==375000;assert 200000+375000*2+50000==1000000
m=json.loads((R/'internal/REVIEW_MANIFEST.json').read_text());m.update(status='READY_FOR_OWNER_REVIEW',visual_review={'pages_reviewed':27,'contacts_reviewed':7,'final_05_shorter_labels_verified':True,'source_pdf08_09_unchanged':True},acceptance_checks=checks)
p=R/'output/P7_Dogovor_subpodryada_v1.zip'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED)as z:
 for f in sorted((R/'candidate').iterdir()):
  info=zipfile.ZipInfo(f.name,(2026,10,30,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,f.read_bytes())
with zipfile.ZipFile(p)as z:
 assert z.testzip()is None and len(z.namelist())==11
 assert all(H(z.read(x['name']))==x['sha256']for x in m['files'])
m['archive']={'name':p.name,'sha256':H(p.read_bytes()),'bytes':p.stat().st_size};(R/'internal/REVIEW_MANIFEST.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));print(json.dumps({'archive':m['archive'],'preview':m['preview']}))
