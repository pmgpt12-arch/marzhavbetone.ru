import fs from 'node:fs/promises';
import {FileBlob,SpreadsheetFile} from '@oai/artifact-tool';
const root='/workspace/scratch/1c70cef937ec/qa18-p7',out='/workspace/scratch/1c70cef937ec/outputs/qa18-p7';await fs.mkdir(out,{recursive:true});
const names=['02-perechen-rabot.xlsx','03-kalendarnyy-plan.xlsx','05-grafik-platezhey.xlsx'];
for(const name of names){
 const w=await SpreadsheetFile.importXlsx(await FileBlob.load(root+'/source/'+name));
 await fs.writeFile(root+'/internal/'+name+'-before.json',(await w.inspect({kind:'sheet',include:'id,name',maxChars:1000})).ndjson);
 const s=w.worksheets.getItem('Реестр'),last=name.startsWith('05')?'J':'I';
 s.getRange('A2').format.rowHeight=48;s.getRange('A2').format.wrapText=true;
 s.getRange('A3:'+last+'3').format.rowHeight=48;s.getRange('A3:'+last+'3').format.wrapText=true;
 s.getRange('A106:'+last+'106').format.rowHeight=66;s.getRange('A106:'+last+'106').format.wrapText=true;
 const ins=w.worksheets.getItem('Инструкция');ins.getRange('A1:A3').format.columnWidth=86;ins.getRange('A3').format.wrapText=true;ins.getRange('A3').format.rowHeight=132;
 if(name.startsWith('03')){s.getRange('E3').values=[['Длительность, календ. дни']];ins.getRange('A3').values=[['Внесите начальную и конечную даты, зависимости, передачу фронта, исходных данных и ответственного. Длительность указывается вручную в календарных днях: для непрерывного периода с включением обеих дат — окончание минус начало плюс один. Если договор определяет иной порядок, зафиксируйте его отдельно. Даты не рассчитываются автоматически. Сверьте график с пунктами 2.1, 3.2 и 4.1 договора.']];}
 if(name.startsWith('05')){s.getRange('A3:J3').format.font.size=10;s.getRange('C3:J3').values=[['Сумма, ₽','Погашение аванса, ₽','Удержание, ₽','К выплате, ₽','Дата события','Срок оплаты','План оплаты','Факт оплаты']];ins.getRange('A3').values=[['Все суммы и даты заполняются вручную: автоматических формул в шаблоне нет. Для оплаты принятых работ: к перечислению = сумма по основанию минус погашение ранее полученного аванса минус гарантийное удержание. Первоначальную выплату аванса и возврат удержания отражайте отдельными строками с соответствующим основанием. Не вычитайте аванс повторно. Договорное событие и срок сверьте с пунктами 3.2, 3.3 и 6.3 договора. Пример сверки — в начальной PDF-инструкции.']];}
 w.recalculate();await fs.writeFile(root+'/internal/'+name+'-after.json',(await w.inspect({kind:'table',range:'Реестр!A1:'+last+'3',tableMaxRows:3,tableMaxCols:10,maxChars:2500})).ndjson);
 const preview=await w.render({sheetName:'Реестр',range:'A1:'+last+'5',scale:1,format:'png'});await fs.writeFile(root+'/internal/'+name+'-artifact.png',new Uint8Array(await preview.arrayBuffer()));
 await(await SpreadsheetFile.exportXlsx(w)).save(out+'/'+name);console.log('Exported '+name);
}
