<?php
/**
 * Webhook для получения уведомлений от ЮКасса
 * 
 * URL для настройки в личном кабинете ЮКасса:
 * https://marzhavbetone.ru/webhook.php
 */
declare(strict_types=1);

require __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');

// Получаем тело запроса
$body = file_get_contents('php://input');
$event = json_decode($body, true);

if (!$event || empty($event['event']) || empty($event['object'])) {
    http_response_code(400);
    echo json_encode(['ok' => false], JSON_UNESCAPED_UNICODE);
    exit;
}

$payment = $event['object'];
$paymentId = $payment['id'] ?? '';
$status = $payment['status'] ?? '';
$orderId = $payment['metadata']['order_id'] ?? '';

if (!$orderId) {
    http_response_code(400);
    echo json_encode(['ok' => false], JSON_UNESCAPED_UNICODE);
    exit;
}

// Находим заказ
$orderFile = ORDERS_DIR . '/' . $orderId . '.json';
if (!file_exists($orderFile)) {
    http_response_code(404);
    echo json_encode(['ok' => false], JSON_UNESCAPED_UNICODE);
    exit;
}

$order = json_decode(file_get_contents($orderFile), true);
if (!$order) {
    http_response_code(500);
    echo json_encode(['ok' => false], JSON_UNESCAPED_UNICODE);
    exit;
}

// Обновляем статус
$order['payment_status'] = $status;
$order['payment_id'] = $paymentId;
$order['updated_at'] = date('c');

// Обработка событий
switch ($event['event']) {
    case 'payment.succeeded':
        $order['status'] = 'paid';
        $order['paid_at'] = date('c');
        
        // Отправляем email админу
        $itemsText = [];
        foreach ($order['items'] ?? [] as $item) {
            $price = number_format((int)$item['price'] / 100, 0, '', ' ');
            $itemsText[] = '- ' . ($item['name'] ?? 'Товар') . ' — ' . $price . ' ₽';
        }
        $totalFormatted = number_format($order['total'] / 100, 0, '', ' ');
        
        $subject = '✅ Оплачен заказ ' . $orderId;
        $emailBody = "Новый оплаченный заказ:\n\n";
        $emailBody .= "ID заказа: {$orderId}\n";
        $emailBody .= "Email: " . ($order['email'] ?: 'не указан') . "\n";
        $emailBody .= "Телефон: " . ($order['phone'] ?: 'не указан') . "\n";
        $emailBody .= "Сумма: {$totalFormatted} ₽\n\n";
        $emailBody .= "Товары:\n" . implode("\n", $itemsText) . "\n\n";
        $emailBody .= "Payment ID: {$paymentId}\n";
        $emailBody .= "Дата: " . date('d.m.Y H:i:s') . "\n";
        
        $headers = [
            'From: site@marzhavbetone.ru',
            'Reply-To: ' . ($order['email'] ?: ADMIN_EMAIL),
            'Content-Type: text/plain; charset=UTF-8',
        ];
        mail(ADMIN_EMAIL, '=?UTF-8?B?' . base64_encode($subject) . '?=', $emailBody, implode("\r\n", $headers));
        break;
        
    case 'payment.canceled':
        $order['status'] = 'canceled';
        break;
        
    case 'payment.waiting_for_capture':
        $order['status'] = 'waiting_for_capture';
        break;
}

// Сохраняем обновлённый заказ
file_put_contents($orderFile, json_encode($order, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

// Отвечаем ЮКассе успехом
echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE);
